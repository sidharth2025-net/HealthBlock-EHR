import React, { useEffect, useState } from 'react';
import api from '../services/api';
export default function PatientDashboard(){ const [records,setRecords]=useState([]);
  useEffect(()=>{ fetchRecords(); },[]);
  async function fetchRecords(){ const token = localStorage.getItem('token'); const res = await api.get('/patient/records', { headers:{ Authorization:`Bearer ${token}` }}); setRecords(res.data); }
  return (<div><h2>My Records</h2><ul>{records.map(r=> <li key={r.id}>{r.title} — {r.cid}</li>)}</ul></div>);
}
