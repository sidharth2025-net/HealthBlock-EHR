import React from 'react';
export default function DoctorDashboard(){ return (<div><h2>Doctor Dashboard (placeholder)</h2></div>); }
