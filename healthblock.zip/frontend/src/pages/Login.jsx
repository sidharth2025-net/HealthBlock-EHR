import React, { useState } from 'react';
import api from '../services/api';
export default function Login({ onLogin }){
  const [email,setEmail]=useState(''); const [password,setPassword]=useState('');
  async function submit(e){ e.preventDefault(); const res = await api.post('/auth/login',{email,password}); localStorage.setItem('token', res.data.token); if(onLogin) onLogin(); }
  return (<form onSubmit={submit}><input value={email} onChange={e=>setEmail(e.target.value)} placeholder='email'/><input value={password} onChange={e=>setPassword(e.target.value)} placeholder='password' type='password'/><button>Login</button></form>);
}
