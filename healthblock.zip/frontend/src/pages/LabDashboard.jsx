import React from 'react';
export default function LabDashboard(){ return (<div><h2>Lab Dashboard (placeholder)</h2></div>); }
