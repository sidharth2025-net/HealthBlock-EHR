import React from 'react';
export default function App(){
  return (<div style={{padding:20}}><h1>HealthBlock - Frontend (placeholder)</h1><p>Use the API backend to interact.</p></div>);
}
