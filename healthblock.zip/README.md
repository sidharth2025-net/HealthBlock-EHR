# HealthBlock - Minimal scaffold

This is a minimal scaffold for the HealthBlock project (backend + frontend). Backend uses Express + Sequelize + Postgres + IPFS; frontend is a small React placeholder.

## Quick start
1. Start postgres and ipfs: `docker-compose up -d`
2. Backend: cd backend && npm install && set env vars (DB_*, IPFS_API_URL=http://localhost:5001) && npm run dev
3. Frontend: cd frontend && npm install && npm start

Notes: This scaffold provides starter code. For production, add encryption before uploading to IPFS and HTTPS, proper CORS, validation, and logging.
