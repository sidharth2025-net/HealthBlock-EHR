const { create } = require('ipfs-http-client');
const config = require('../config/config');

const client = create({ url: config.ipfs.apiUrl });

module.exports = {
  addJSON: async (obj) => {
    const buffer = Buffer.from(JSON.stringify(obj));
    const result = await client.add(buffer);
    return result.cid.toString();
  },
  addFile: async (fileBuffer, fileName) => {
    const result = await client.add({ path: fileName, content: fileBuffer });
    return result.cid.toString();
  },
  get: async (cid) => {
    const stream = client.cat(cid);
    let data = '';
    for await (const chunk of stream) {
      data += chunk.toString();
    }
    return data;
  }
};
