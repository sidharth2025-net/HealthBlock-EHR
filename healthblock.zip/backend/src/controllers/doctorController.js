const { PatientRecord, Permission } = require('../models');
const ipfs = require('../utils/ipfsClient');

exports.viewRecordIfPermitted = async (req, res) => {
  try {
    const { recordId } = req.params;
    const perm = await Permission.findOne({ where: { recordId, granteeUserId: req.user.id, granted: true } });
    if (!perm) return res.status(403).json({ message: 'No access' });
    const rec = await PatientRecord.findByPk(recordId);
    const data = await ipfs.get(rec.cid);
    let parsed = null;
    try { parsed = JSON.parse(data); } catch(e) { parsed = data; }
    res.json({ cid: rec.cid, data: parsed });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Server error' });
  }
};

exports.uploadPrescription = async (req, res) => {
  try {
    const { patientId, title } = req.body;
    const fileBuffer = req.file.buffer;
    const cid = await ipfs.addFile(fileBuffer, req.file.originalname);
    const rec = await PatientRecord.create({ cid, title: title || 'prescription', type: 'prescription', ownerUserId: patientId });
    await Permission.create({ recordId: rec.id, granteeUserId: patientId, granted: true, grantedByUserId: req.user.id });
    await Permission.create({ recordId: rec.id, granteeUserId: req.user.id, granted: true, grantedByUserId: req.user.id });
    res.json({ recordId: rec.id, cid });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Server error' });
  }
};
