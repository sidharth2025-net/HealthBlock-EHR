const { PatientRecord, Permission } = require('../models');
const ipfs = require('../utils/ipfsClient');

exports.createProfile = async (req, res) => {
  try {
    const { profile } = req.body;
    if (req.user.role !== 'patient') return res.status(403).json({ message: 'Only patient' });
    const cid = await ipfs.addJSON(profile);
    const rec = await PatientRecord.create({ cid, title: 'profile', type: 'profile', ownerUserId: req.user.id });
    res.json({ recordId: rec.id, cid });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Server error' });
  }
};

exports.grantAccess = async (req, res) => {
  try {
    const { recordId, granteeId } = req.body;
    const rec = await PatientRecord.findByPk(recordId);
    if (!rec) return res.status(404).json({ message: 'Record not found' });
    if (rec.ownerUserId !== req.user.id) return res.status(403).json({ message: 'Not owner' });
    const p = await Permission.create({ recordId, granteeUserId: granteeId, granted: true, grantedByUserId: req.user.id });
    res.json({ message: 'Granted', permissionId: p.id });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Server error' });
  }
};

exports.revokeAccess = async (req, res) => {
  try {
    const { recordId, granteeId } = req.body;
    const perm = await Permission.findOne({ where: { recordId, granteeUserId: granteeId } });
    if (!perm) return res.status(404).json({ message: 'No permission found' });
    if (perm.grantedByUserId !== req.user.id && req.user.role !== 'admin') return res.status(403).json({ message: 'Not allowed' });
    perm.granted = false;
    await perm.save();
    res.json({ message: 'Revoked' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Server error' });
  }
};

exports.listMyRecords = async (req, res) => {
  try {
    const recs = await PatientRecord.findAll({ where: { ownerUserId: req.user.id } });
    res.json(recs);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Server error' });
  }
};
