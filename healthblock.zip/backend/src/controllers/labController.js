const { PatientRecord, Permission } = require('../models');
const ipfs = require('../utils/ipfsClient');

exports.uploadLabReport = async (req, res) => {
  try {
    const { patientId, title } = req.body;
    const perm = await Permission.findOne({ where: { granteeUserId: req.user.id, granted: true } });
    if (!perm) return res.status(403).json({ message: 'No permission to upload' });
    const cid = await ipfs.addFile(req.file.buffer, req.file.originalname);
    const rec = await PatientRecord.create({ cid, title: title || 'lab-report', type: 'lab-report', ownerUserId: patientId });
    await Permission.create({ recordId: rec.id, granteeUserId: patientId, granted: true, grantedByUserId: req.user.id });
    await Permission.create({ recordId: rec.id, granteeUserId: req.user.id, granted: true, grantedByUserId: req.user.id });
    res.json({ recordId: rec.id, cid });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Server error' });
  }
};
