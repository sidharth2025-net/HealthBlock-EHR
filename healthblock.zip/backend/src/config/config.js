module.exports = {
  jwtSecret: process.env.JWT_SECRET || 'supersecret_healthblock',
  db: {
    database: process.env.DB_NAME || 'healthblock',
    username: process.env.DB_USER || 'healthblock',
    password: process.env.DB_PASS || 'password',
    host: process.env.DB_HOST || 'localhost',
    dialect: 'postgres'
  },
  ipfs: {
    apiUrl: process.env.IPFS_API_URL || 'http://localhost:5001'
  }
};
