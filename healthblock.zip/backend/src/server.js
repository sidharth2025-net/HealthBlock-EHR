const express = require('express');
const bodyParser = require('body-parser');
const { sequelize } = require('./models');
const authRoutes = require('./routes/auth');
const patientRoutes = require('./routes/patients');
const doctorRoutes = require('./routes/doctors');
const labRoutes = require('./routes/labs');

const app = express();
app.use(bodyParser.json({ limit: '10mb' }));

app.use('/auth', authRoutes);
app.use('/patient', patientRoutes);
app.use('/doctor', doctorRoutes);
app.use('/lab', labRoutes);

const PORT = process.env.PORT || 4000;
(async () => {
  await sequelize.sync({ alter: true });
  app.listen(PORT, () => console.log('Server started on', PORT));
})();
