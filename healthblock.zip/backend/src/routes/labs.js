const express = require('express');
const router = express.Router();
const authMiddleware = require('../middleware/auth');
const roles = require('../middleware/roles');
const ctrl = require('../controllers/labController');
const multer = require('multer');
const upload = multer();

router.post('/upload', authMiddleware, roles(['lab']), upload.single('file'), ctrl.uploadLabReport);

module.exports = router;
