const express = require('express');
const router = express.Router();
const authMiddleware = require('../middleware/auth');
const roles = require('../middleware/roles');
const ctrl = require('../controllers/doctorController');
const multer = require('multer');
const upload = multer();

router.get('/record/:recordId', authMiddleware, roles(['doctor']), ctrl.viewRecordIfPermitted);
router.post('/prescribe', authMiddleware, roles(['doctor']), upload.single('file'), ctrl.uploadPrescription);

module.exports = router;
