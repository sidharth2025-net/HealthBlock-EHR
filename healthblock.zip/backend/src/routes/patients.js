const express = require('express');
const router = express.Router();
const authMiddleware = require('../middleware/auth');
const roles = require('../middleware/roles');
const ctrl = require('../controllers/patientController');

router.post('/profile', authMiddleware, roles(['patient']), ctrl.createProfile);
router.post('/grant', authMiddleware, roles(['patient']), ctrl.grantAccess);
router.post('/revoke', authMiddleware, roles(['patient']), ctrl.revokeAccess);
router.get('/records', authMiddleware, roles(['patient']), ctrl.listMyRecords);

module.exports = router;
