const { DataTypes } = require('sequelize');
const sequelize = require('../db');
const User = require('./user');

const PatientRecord = sequelize.define('PatientRecord', {
  id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
  cid: { type: DataTypes.STRING, allowNull: false },
  title: { type: DataTypes.STRING },
  description: { type: DataTypes.TEXT },
  type: { type: DataTypes.STRING },
});

PatientRecord.belongsTo(User, { as: 'owner', foreignKey: 'ownerUserId' });

module.exports = PatientRecord;
