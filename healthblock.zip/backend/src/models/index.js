const sequelize = require('../db');
const User = require('./user');
const PatientRecord = require('./patientRecord');
const Permission = require('./permission');

module.exports = { sequelize, User, PatientRecord, Permission };
