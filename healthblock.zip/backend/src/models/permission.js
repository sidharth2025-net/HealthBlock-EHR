const { DataTypes } = require('sequelize');
const sequelize = require('../db');
const PatientRecord = require('./patientRecord');
const User = require('./user');

const Permission = sequelize.define('Permission', {
  id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
  granted: { type: DataTypes.BOOLEAN, defaultValue: false }
});

Permission.belongsTo(PatientRecord, { foreignKey: 'recordId' });
Permission.belongsTo(User, { as: 'grantee', foreignKey: 'granteeUserId' });
Permission.belongsTo(User, { as: 'grantedBy', foreignKey: 'grantedByUserId' });

module.exports = Permission;
