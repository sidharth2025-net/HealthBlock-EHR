// SPDX-License-Identifier: MIT
pragma solidity ^0.8.17;

contract HealthRecordSystem {
    
    // Structures
    struct Doctor {
        address walletAddress;
        string fullName;
        string hospitalName;
        string hospitalLocation;
        string dateOfBirth;
        string gender;
        string email;
        string hhNumber;
        string specialization;
        string department;
        string designation;
        uint256 workExperience;
        bool isRegistered;
    }
    
    struct Patient {
        address walletAddress;
        string fullName;
        string dateOfBirth;
        string gender;
        string bloodGroup;
        string residentialAddress;
        string email;
        bool isRegistered;
    }
    
    struct DiagnosticCenter {
        address walletAddress;
        string centerName;
        string hospitalName;
        string location;
        string email;
        string hhNumber;
        bool isRegistered;
    }
    
    struct MedicalRecord {
        string recordId;
        address patientAddress;
        address doctorAddress;
        string ipfsHash;
        uint256 timestamp;
        string recordType;
        bool exists;
    }
    
    struct Consultation {
        string recordId;
        address patientAddress;
        address doctorAddress;
        string patientName;
        string diagnosis;
        string prescription;
        uint256 timestamp;
    }
    
    struct LabReport {
        string recordId;
        address patientAddress;
        address diagnosticAddress;
        string patientName;
        string doctorName;
        uint256 age;
        string gender;
        string bloodGroup;
        string reportIpfsHash;
        uint256 timestamp;
    }
    
    struct AccessPermission {
        address patient;
        address doctor;
        bool hasAccess;
        uint256 grantedAt;
    }
    
    // Mappings
    mapping(address => Doctor) public doctors;
    mapping(address => Patient) public patients;
    mapping(address => DiagnosticCenter) public diagnosticCenters;
    mapping(string => MedicalRecord) public medicalRecords;
    mapping(string => Consultation) public consultations;
    mapping(string => LabReport) public labReports;
    mapping(bytes32 => AccessPermission) public accessPermissions;
    mapping(address => string[]) public patientRecords;
    mapping(address => address[]) public patientDoctors;
    
    // Arrays
    address[] public doctorList;
    address[] public patientList;
    address[] public diagnosticCenterList;
    
    // Events
    event DoctorRegistered(address indexed doctorAddress, string fullName);
    event PatientRegistered(address indexed patientAddress, string fullName);
    event DiagnosticCenterRegistered(address indexed centerAddress, string centerName);
    event RecordAdded(string recordId, address indexed patient, address indexed doctor);
    event ConsultationAdded(string recordId, address indexed patient, address indexed doctor);
    event LabReportAdded(string recordId, address indexed patient, address indexed diagnostic);
    event AccessGranted(address indexed patient, address indexed doctor);
    event AccessRevoked(address indexed patient, address indexed doctor);
    
    // Modifiers
    modifier onlyDoctor() {
        require(doctors[msg.sender].isRegistered, "Only registered doctors can perform this action");
        _;
    }
    
    modifier onlyPatient() {
        require(patients[msg.sender].isRegistered, "Only registered patients can perform this action");
        _;
    }
    
    modifier onlyDiagnostic() {
        require(diagnosticCenters[msg.sender].isRegistered, "Only registered diagnostic centers can perform this action");
        _;
    }
    
    // Doctor Functions
    function registerDoctor(
        string memory _fullName,
        string memory _hospitalName,
        string memory _hospitalLocation,
        string memory _dateOfBirth,
        string memory _gender,
        string memory _email,
        string memory _hhNumber,
        string memory _specialization,
        string memory _department,
        string memory _designation,
        uint256 _workExperience
    ) public {
        require(!doctors[msg.sender].isRegistered, "Doctor already registered");
        
        doctors[msg.sender] = Doctor({
            walletAddress: msg.sender,
            fullName: _fullName,
            hospitalName: _hospitalName,
            hospitalLocation: _hospitalLocation,
            dateOfBirth: _dateOfBirth,
            gender: _gender,
            email: _email,
            hhNumber: _hhNumber,
            specialization: _specialization,
            department: _department,
            designation: _designation,
            workExperience: _workExperience,
            isRegistered: true
        });
        
        doctorList.push(msg.sender);
        emit DoctorRegistered(msg.sender, _fullName);
    }
    
    // Patient Functions
    function registerPatient(
        string memory _fullName,
        string memory _dateOfBirth,
        string memory _gender,
        string memory _bloodGroup,
        string memory _residentialAddress,
        string memory _email
    ) public {
        require(!patients[msg.sender].isRegistered, "Patient already registered");
        
        patients[msg.sender] = Patient({
            walletAddress: msg.sender,
            fullName: _fullName,
            dateOfBirth: _dateOfBirth,
            gender: _gender,
            bloodGroup: _bloodGroup,
            residentialAddress: _residentialAddress,
            email: _email,
            isRegistered: true
        });
        
        patientList.push(msg.sender);
        emit PatientRegistered(msg.sender, _fullName);
    }
    
    // Diagnostic Center Functions
    function registerDiagnosticCenter(
        string memory _centerName,
        string memory _hospitalName,
        string memory _location,
        string memory _email,
        string memory _hhNumber
    ) public {
        require(!diagnosticCenters[msg.sender].isRegistered, "Diagnostic center already registered");
        
        diagnosticCenters[msg.sender] = DiagnosticCenter({
            walletAddress: msg.sender,
            centerName: _centerName,
            hospitalName: _hospitalName,
            location: _location,
            email: _email,
            hhNumber: _hhNumber,
            isRegistered: true
        });
        
        diagnosticCenterList.push(msg.sender);
        emit DiagnosticCenterRegistered(msg.sender, _centerName);
    }
    
    // Medical Record Functions
    function addMedicalRecord(
        string memory _recordId,
        address _patientAddress,
        string memory _ipfsHash,
        string memory _recordType
    ) public onlyPatient {
        require(patients[_patientAddress].isRegistered, "Patient not registered");
        require(!medicalRecords[_recordId].exists, "Record already exists");
        
        medicalRecords[_recordId] = MedicalRecord({
            recordId: _recordId,
            patientAddress: _patientAddress,
            doctorAddress: address(0),
            ipfsHash: _ipfsHash,
            timestamp: block.timestamp,
            recordType: _recordType,
            exists: true
        });
        
        patientRecords[_patientAddress].push(_recordId);
        emit RecordAdded(_recordId, _patientAddress, address(0));
    }
    
    // Consultation Functions
    function addConsultation(
        string memory _recordId,
        address _patientAddress,
        string memory _patientName,
        string memory _diagnosis,
        string memory _prescription
    ) public onlyDoctor {
        require(patients[_patientAddress].isRegistered, "Patient not registered");
        require(hasAccess(msg.sender, _patientAddress), "No access permission");
        
        consultations[_recordId] = Consultation({
            recordId: _recordId,
            patientAddress: _patientAddress,
            doctorAddress: msg.sender,
            patientName: _patientName,
            diagnosis: _diagnosis,
            prescription: _prescription,
            timestamp: block.timestamp
        });
        
        patientRecords[_patientAddress].push(_recordId);
        emit ConsultationAdded(_recordId, _patientAddress, msg.sender);
    }
    
    // Lab Report Functions
    function addLabReport(
        string memory _recordId,
        address _patientAddress,
        string memory _patientName,
        string memory _doctorName,
        uint256 _age,
        string memory _gender,
        string memory _bloodGroup,
        string memory _reportIpfsHash
    ) public onlyDiagnostic {
        require(patients[_patientAddress].isRegistered, "Patient not registered");
        
        labReports[_recordId] = LabReport({
            recordId: _recordId,
            patientAddress: _patientAddress,
            diagnosticAddress: msg.sender,
            patientName: _patientName,
            doctorName: _doctorName,
            age: _age,
            gender: _gender,
            bloodGroup: _bloodGroup,
            reportIpfsHash: _reportIpfsHash,
            timestamp: block.timestamp
        });
        
        patientRecords[_patientAddress].push(_recordId);
        emit LabReportAdded(_recordId, _patientAddress, msg.sender);
    }
    
    // Access Control Functions
    function grantAccess(address _doctorAddress) public onlyPatient {
        require(doctors[_doctorAddress].isRegistered, "Doctor not registered");
        
        bytes32 permissionKey = keccak256(abi.encodePacked(msg.sender, _doctorAddress));
        accessPermissions[permissionKey] = AccessPermission({
            patient: msg.sender,
            doctor: _doctorAddress,
            hasAccess: true,
            grantedAt: block.timestamp
        });
        
        patientDoctors[msg.sender].push(_doctorAddress);
        emit AccessGranted(msg.sender, _doctorAddress);
    }
    
    function revokeAccess(address _doctorAddress) public onlyPatient {
        bytes32 permissionKey = keccak256(abi.encodePacked(msg.sender, _doctorAddress));
        accessPermissions[permissionKey].hasAccess = false;
        emit AccessRevoked(msg.sender, _doctorAddress);
    }
    
    function hasAccess(address _doctorAddress, address _patientAddress) public view returns (bool) {
        bytes32 permissionKey = keccak256(abi.encodePacked(_patientAddress, _doctorAddress));
        return accessPermissions[permissionKey].hasAccess;
    }
    
    // View Functions
    function getDoctor(address _address) public view returns (Doctor memory) {
        return doctors[_address];
    }
    
    function getPatient(address _address) public view returns (Patient memory) {
        return patients[_address];
    }
    
    function getDiagnosticCenter(address _address) public view returns (DiagnosticCenter memory) {
        return diagnosticCenters[_address];
    }
    
    function getMedicalRecord(string memory _recordId) public view returns (MedicalRecord memory) {
        return medicalRecords[_recordId];
    }
    
    function getConsultation(string memory _recordId) public view returns (Consultation memory) {
        return consultations[_recordId];
    }
    
    function getLabReport(string memory _recordId) public view returns (LabReport memory) {
        return labReports[_recordId];
    }
    
    function getPatientRecords(address _patientAddress) public view returns (string[] memory) {
        return patientRecords[_patientAddress];
    }
    
    function getPatientDoctors(address _patientAddress) public view returns (address[] memory) {
        return patientDoctors[_patientAddress];
    }
    
    function getDoctorCount() public view returns (uint256) {
        return doctorList.length;
    }
    
    function getPatientCount() public view returns (uint256) {
        return patientList.length;
    }
    
    function getDiagnosticCenterCount() public view returns (uint256) {
        return diagnosticCenterList.length;
    }
}
