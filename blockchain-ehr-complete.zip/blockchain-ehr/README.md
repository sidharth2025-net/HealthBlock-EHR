# Blockchain-Based Electronic Health Records (EHR) System

A decentralized healthcare record management system built with blockchain technology, IPFS, and smart contracts.

## 🌟 Features

- **Blockchain Security**: Immutable and tamper-proof record storage using Ethereum
- **Decentralized Storage**: IPFS integration for secure medical file storage
- **Access Control**: Patient-controlled permissions for healthcare providers
- **Three User Roles**: Patients, Doctors, and Diagnostic Centers
- **Smart Contracts**: Automated and trustless record management
- **MetaMask Integration**: Seamless blockchain wallet connectivity

## 🛠️ Technology Stack

- **Blockchain**: Ethereum (Ganache for local development)
- **Smart Contracts**: Solidity ^0.8.17
- **Development Framework**: Truffle
- **Frontend**: HTML, CSS, JavaScript
- **Backend**: Node.js, Express
- **Decentralized Storage**: IPFS (Kubo)
- **Wallet**: MetaMask
- **Web3 Library**: Web3.js

## 📋 Prerequisites

Before you begin, ensure you have the following installed:

1. **Node.js** (v14 or higher)
   ```bash
   node --version
   npm --version
   ```

2. **Ganache** - Local blockchain
   - Download from: https://trufflesuite.com/ganache/
   - Or install CLI version: `npm install -g ganache`

3. **Truffle** - Smart contract development framework
   ```bash
   npm install -g truffle
   ```

4. **IPFS Kubo** - Decentralized storage
   - Download from: https://docs.ipfs.tech/install/command-line/
   - Or use Docker: `docker run -d -p 4001:4001 -p 8080:8080 -p 5001:5001 ipfs/kubo`

5. **MetaMask** - Browser wallet extension
   - Install from: https://metamask.io/

## 🚀 Installation & Setup

### Step 1: Clone or Extract the Project

```bash
cd blockchain-ehr
```

### Step 2: Install Dependencies

```bash
npm install
```

### Step 3: Start Ganache

**Option A: Using Ganache GUI**
1. Open Ganache application
2. Create a new workspace or quickstart
3. Note the RPC Server address (default: HTTP://127.0.0.1:7545)
4. Note the Network ID (default: 5777)

**Option B: Using Ganache CLI**
```bash
ganache --port 7545 --networkId 5777
```

Keep this terminal running.

### Step 4: Configure MetaMask

1. Open MetaMask in your browser
2. Add a new network with these details:
   - Network Name: `Ganache Local`
   - RPC URL: `http://127.0.0.1:7545`
   - Chain ID: `1337` (or `5777` depending on your Ganache config)
   - Currency Symbol: `ETH`

3. Import accounts from Ganache:
   - Copy a private key from Ganache
   - In MetaMask: Import Account → Paste private key

### Step 5: Start IPFS

**Option A: IPFS Desktop**
1. Download and install IPFS Desktop
2. Start the application
3. Ensure API is running on port 5001

**Option B: IPFS Command Line**
```bash
# Initialize IPFS (first time only)
ipfs init

# Start IPFS daemon
ipfs daemon
```

Keep this terminal running.

### Step 6: Compile Smart Contracts

```bash
truffle compile
```

### Step 7: Deploy Smart Contracts

```bash
truffle migrate --reset --network ganache
```

You should see output showing the contract addresses. The contract address will be automatically saved.

### Step 8: Start the Application Server

```bash
npm start
```

Or for development with auto-reload:
```bash
npm run dev
```

The server will start on http://localhost:3000

## 📖 Usage Guide

### For Patients

1. **Register**
   - Navigate to the Register page
   - Click "Register as Patient"
   - Connect your MetaMask wallet
   - Fill in your details
   - Confirm the blockchain transaction
   - Save your HH Number for login

2. **Login**
   - Use your HH Number and password
   - Ensure MetaMask is connected with the same wallet

3. **Upload Medical Records**
   - Go to "Upload Past Records"
   - Select your medical file (PDF, images)
   - Files are uploaded to IPFS and hash stored on blockchain

4. **Grant Doctor Access**
   - Enter doctor's HH Number
   - Confirm blockchain transaction
   - Doctor can now view your records

### For Doctors

1. **Register**
   - Navigate to Register page
   - Click "Register as Doctor"
   - Fill in professional details
   - Confirm blockchain transaction

2. **Login**
   - Use your HH Number and password

3. **View Patient List**
   - See all patients who granted you access
   - View patient profiles and medical history

4. **Create Consultation**
   - Select a patient
   - Fill in diagnosis and prescription
   - Create record on blockchain

### For Diagnostic Centers

1. **Register**
   - Register as Diagnostic Center
   - Provide center details

2. **Create Lab Reports**
   - Enter patient information
   - Upload report PDF
   - Record is stored on IPFS and blockchain

## 🏗️ Project Structure

```
blockchain-ehr/
├── contracts/              # Solidity smart contracts
│   ├── HealthRecordSystem.sol
│   └── Migrations.sol
├── migrations/             # Deployment scripts
│   ├── 1_initial_migration.js
│   └── 2_deploy_contracts.js
├── public/                 # Frontend files
│   ├── css/
│   │   └── style.css
│   ├── js/
│   │   ├── web3-handler.js
│   │   ├── main.js
│   │   ├── register.js
│   │   ├── login.js
│   │   ├── patient-dashboard.js
│   │   ├── doctor-dashboard.js
│   │   └── diagnostic-dashboard.js
│   ├── index.html
│   ├── register.html
│   ├── login.html
│   ├── about.html
│   ├── patient-dashboard.html
│   ├── doctor-dashboard.html
│   └── diagnostic-dashboard.html
├── build/                  # Compiled contracts (auto-generated)
├── server.js              # Express server
├── truffle-config.js      # Truffle configuration
├── package.json
├── .env
└── README.md
```

## 🔑 Smart Contract Functions

### Patient Functions
- `registerPatient()` - Register new patient
- `addMedicalRecord()` - Upload medical record
- `grantAccess()` - Grant doctor access
- `revokeAccess()` - Revoke doctor access
- `getPatientRecords()` - Get all patient records

### Doctor Functions
- `registerDoctor()` - Register new doctor
- `addConsultation()` - Create consultation record
- `getPatient()` - Get patient information
- `hasAccess()` - Check access permission

### Diagnostic Functions
- `registerDiagnosticCenter()` - Register diagnostic center
- `addLabReport()` - Create lab report

## 🔒 Security Features

1. **Blockchain Immutability**: Records cannot be altered once stored
2. **Access Control**: Patient-controlled permissions
3. **Encryption**: Files stored on IPFS with hash verification
4. **Wallet Authentication**: MetaMask wallet-based login
5. **Smart Contract Security**: Access modifiers and validation

## 🐛 Troubleshooting

### MetaMask Connection Issues
- Ensure you're on the correct network (Ganache Local)
- Check that Ganache is running
- Try refreshing the page
- Reset MetaMask account if needed

### Contract Not Deployed
- Run `truffle migrate --reset`
- Check Ganache is running on port 7545
- Verify network configuration in truffle-config.js

### IPFS Upload Fails
- Ensure IPFS daemon is running
- Check IPFS API is accessible on port 5001
- Verify CORS settings in IPFS config

### Transaction Fails
- Ensure you have enough ETH in your wallet
- Check gas limits in MetaMask
- Verify you're using the correct wallet address

## 📝 Environment Variables

Create/modify `.env` file:

```env
PORT=3000
GANACHE_URL=http://127.0.0.1:7545
IPFS_HOST=127.0.0.1
IPFS_PORT=5001
IPFS_PROTOCOL=http
CONTRACT_ADDRESS=(auto-filled after deployment)
```

## 🧪 Testing

Run contract tests:

```bash
truffle test
```

## 🚢 Deployment to Production

For production deployment:

1. Update `truffle-config.js` with production network
2. Use services like Infura for Ethereum node
3. Deploy to mainnet or testnet (Sepolia, Goerli)
4. Use Pinata or similar for IPFS pinning
5. Implement proper authentication backend
6. Add HTTPS support
7. Implement proper key management

## 📄 License

MIT License - feel free to use this project for learning and development.

## 🤝 Contributing

Contributions are welcome! Please feel free to submit pull requests.

## 📞 Support

For issues and questions:
- Open an issue on GitHub
- Check existing documentation
- Review Truffle and Web3.js docs

## 🎯 Future Enhancements

- [ ] Multi-signature approvals
- [ ] Advanced analytics dashboard
- [ ] Mobile application
- [ ] Integration with existing EHR systems
- [ ] AI-powered health insights
- [ ] Telemedicine integration
- [ ] Insurance claim automation
- [ ] Prescription verification system

## ⚠️ Disclaimer

This is a educational/prototype system. For production healthcare applications:
- Implement proper security audits
- Ensure HIPAA compliance
- Add comprehensive error handling
- Implement proper encryption
- Use secure authentication methods
- Follow healthcare data regulations

---

**Built with ❤️ using Blockchain Technology**
