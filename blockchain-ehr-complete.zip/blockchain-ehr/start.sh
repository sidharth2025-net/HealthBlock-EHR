#!/bin/bash

echo "========================================"
echo "Blockchain EHR System - Quick Start"
echo "========================================"
echo ""

echo "Step 1: Installing dependencies..."
npm install
if [ $? -ne 0 ]; then
    echo "ERROR: Failed to install dependencies"
    exit 1
fi
echo "Dependencies installed successfully!"
echo ""

echo "Step 2: Please ensure the following are running:"
echo "  - Ganache on port 7545"
echo "  - IPFS daemon"
echo ""
read -p "Press Enter to continue once they are running..."

echo ""
echo "Step 3: Compiling smart contracts..."
truffle compile
if [ $? -ne 0 ]; then
    echo "ERROR: Failed to compile contracts"
    exit 1
fi
echo "Contracts compiled successfully!"
echo ""

echo "Step 4: Deploying smart contracts..."
truffle migrate --reset --network ganache
if [ $? -ne 0 ]; then
    echo "ERROR: Failed to deploy contracts"
    exit 1
fi
echo "Contracts deployed successfully!"
echo ""

echo "Step 5: Starting the application server..."
echo "The application will be available at http://localhost:3000"
echo ""
npm start
