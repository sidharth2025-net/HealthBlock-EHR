const HealthRecordSystem = artifacts.require("HealthRecordSystem");

module.exports = function(deployer) {
  deployer.deploy(HealthRecordSystem);
};
