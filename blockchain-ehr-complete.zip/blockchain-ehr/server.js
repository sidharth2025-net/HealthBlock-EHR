const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const path = require('path');
const fs = require('fs-extra');
const multer = require('multer');
const { create } = require('ipfs-http-client');
const Web3 = require('web3');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

// IPFS Configuration
const ipfs = create({
    host: process.env.IPFS_HOST || '127.0.0.1',
    port: process.env.IPFS_PORT || 5001,
    protocol: process.env.IPFS_PROTOCOL || 'http'
});

// Web3 Configuration
const web3 = new Web3(process.env.GANACHE_URL || 'http://127.0.0.1:7545');

// Multer Configuration for file uploads
const storage = multer.memoryStorage();
const upload = multer({ storage: storage });

// Contract ABI and Address
let contractABI, contractAddress, healthRecordContract;

// Load contract details
async function loadContract() {
    try {
        const contractPath = path.join(__dirname, 'build', 'contracts', 'HealthRecordSystem.json');
        if (fs.existsSync(contractPath)) {
            const contractJSON = JSON.parse(fs.readFileSync(contractPath, 'utf8'));
            contractABI = contractJSON.abi;
            
            // Get network ID
            const networkId = await web3.eth.net.getId();
            const deployedNetwork = contractJSON.networks[networkId];
            
            if (deployedNetwork) {
                contractAddress = deployedNetwork.address;
                healthRecordContract = new web3.eth.Contract(contractABI, contractAddress);
                console.log('Contract loaded successfully at:', contractAddress);
                
                // Update .env file with contract address
                const envPath = path.join(__dirname, '.env');
                let envContent = fs.readFileSync(envPath, 'utf8');
                envContent = envContent.replace(/CONTRACT_ADDRESS=.*/, `CONTRACT_ADDRESS=${contractAddress}`);
                fs.writeFileSync(envPath, envContent);
            } else {
                console.log('Contract not deployed on current network');
            }
        }
    } catch (error) {
        console.error('Error loading contract:', error);
    }
}

// Routes

// Home route
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Get contract details
app.get('/api/contract', (req, res) => {
    res.json({
        address: contractAddress,
        abi: contractABI
    });
});

// Upload file to IPFS
app.post('/api/ipfs/upload', upload.single('file'), async (req, res) => {
    try {
        if (!req.file) {
            return res.status(400).json({ error: 'No file uploaded' });
        }

        const fileBuffer = req.file.buffer;
        const result = await ipfs.add(fileBuffer);
        
        res.json({
            success: true,
            hash: result.path,
            url: `http://127.0.0.1:8080/ipfs/${result.path}`
        });
    } catch (error) {
        console.error('IPFS upload error:', error);
        res.status(500).json({ error: 'Failed to upload to IPFS' });
    }
});

// Get file from IPFS
app.get('/api/ipfs/:hash', async (req, res) => {
    try {
        const hash = req.params.hash;
        const chunks = [];
        
        for await (const chunk of ipfs.cat(hash)) {
            chunks.push(chunk);
        }
        
        const fileBuffer = Buffer.concat(chunks);
        res.send(fileBuffer);
    } catch (error) {
        console.error('IPFS retrieval error:', error);
        res.status(500).json({ error: 'Failed to retrieve from IPFS' });
    }
});

// Register Doctor
app.post('/api/doctor/register', async (req, res) => {
    try {
        const {
            walletAddress,
            fullName,
            hospitalName,
            hospitalLocation,
            dateOfBirth,
            gender,
            email,
            hhNumber,
            specialization,
            department,
            designation,
            workExperience
        } = req.body;

        res.json({
            success: true,
            message: 'Doctor registration data received. Please confirm transaction in MetaMask.',
            data: req.body
        });
    } catch (error) {
        console.error('Doctor registration error:', error);
        res.status(500).json({ error: 'Failed to register doctor' });
    }
});

// Register Patient
app.post('/api/patient/register', async (req, res) => {
    try {
        const {
            walletAddress,
            fullName,
            dateOfBirth,
            gender,
            bloodGroup,
            residentialAddress,
            email
        } = req.body;

        res.json({
            success: true,
            message: 'Patient registration data received. Please confirm transaction in MetaMask.',
            data: req.body
        });
    } catch (error) {
        console.error('Patient registration error:', error);
        res.status(500).json({ error: 'Failed to register patient' });
    }
});

// Register Diagnostic Center
app.post('/api/diagnostic/register', async (req, res) => {
    try {
        const {
            walletAddress,
            centerName,
            hospitalName,
            location,
            email,
            hhNumber
        } = req.body;

        res.json({
            success: true,
            message: 'Diagnostic center registration data received. Please confirm transaction in MetaMask.',
            data: req.body
        });
    } catch (error) {
        console.error('Diagnostic center registration error:', error);
        res.status(500).json({ error: 'Failed to register diagnostic center' });
    }
});

// Health check endpoint
app.get('/api/health', (req, res) => {
    res.json({
        status: 'OK',
        ipfs: 'Connected',
        blockchain: 'Connected',
        contract: contractAddress ? 'Deployed' : 'Not deployed'
    });
});

// Start server
app.listen(PORT, async () => {
    console.log(`Server running on http://localhost:${PORT}`);
    console.log('Loading smart contract...');
    await loadContract();
});

// Graceful shutdown
process.on('SIGINT', () => {
    console.log('\nShutting down server...');
    process.exit(0);
});
