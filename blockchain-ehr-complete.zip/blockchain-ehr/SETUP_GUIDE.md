# Complete Setup Guide - Blockchain EHR System

This guide will walk you through setting up the complete Blockchain Electronic Health Records system from scratch.

## 📦 What You'll Need

### Required Software

1. **Node.js and npm**
   - Download: https://nodejs.org/ (LTS version recommended)
   - Verify installation:
     ```bash
     node --version  # Should show v14+
     npm --version   # Should show v6+
     ```

2. **Ganache - Local Blockchain**
   - Download GUI: https://trufflesuite.com/ganache/
   - OR install CLI globally:
     ```bash
     npm install -g ganache
     ```

3. **Truffle Framework**
   ```bash
   npm install -g truffle
   ```

4. **IPFS Kubo**
   - **Windows**: Download installer from https://docs.ipfs.tech/install/command-line/
   - **Mac**: 
     ```bash
     brew install ipfs
     ```
   - **Linux**:
     ```bash
     wget https://dist.ipfs.tech/kubo/v0.18.0/kubo_v0.18.0_linux-amd64.tar.gz
     tar -xvzf kubo_v0.18.0_linux-amd64.tar.gz
     cd kubo
     sudo bash install.sh
     ```

5. **MetaMask Browser Extension**
   - Chrome/Brave: https://chrome.google.com/webstore
   - Firefox: https://addons.mozilla.org
   - Search for "MetaMask" and install

## 🎬 Step-by-Step Setup

### Step 1: Project Setup

1. Extract the project files to a directory:
   ```bash
   cd blockchain-ehr
   ```

2. Install project dependencies:
   ```bash
   npm install
   ```
   
   This will install:
   - express
   - web3
   - ipfs-http-client
   - truffle
   - And other dependencies

### Step 2: Start Ganache (Local Blockchain)

#### Using Ganache GUI:

1. Open Ganache application
2. Click "Quickstart" or "New Workspace"
3. In Settings:
   - Server tab: Set Port to `7545`
   - Chain ID: `1337` or `5777`
   - Click "Save and Restart"
4. **Important**: Keep Ganache running throughout development
5. Note the displayed accounts and their private keys

#### Using Ganache CLI:

```bash
ganache --port 7545 --networkId 5777 --deterministic
```

Keep this terminal window open!

### Step 3: Configure MetaMask

1. **Open MetaMask** in your browser

2. **Add Ganache Network**:
   - Click the network dropdown (top of MetaMask)
   - Click "Add Network" → "Add a network manually"
   - Enter these details:
     ```
     Network Name: Ganache Local
     RPC URL: http://127.0.0.1:7545
     Chain ID: 1337
     Currency Symbol: ETH
     ```
   - Click "Save"

3. **Import Ganache Account**:
   - In Ganache, click the key icon next to any account
   - Copy the Private Key
   - In MetaMask: Click account icon → "Import Account"
   - Paste the private key
   - Click "Import"
   - You should now see 100 ETH balance

4. **Import Multiple Accounts** (recommended for testing):
   - Repeat step 3 for at least 3 different accounts
   - Label them: "Patient", "Doctor", "Diagnostic"

### Step 4: Start IPFS

#### Option A: IPFS Desktop (Easiest)

1. Download IPFS Desktop from https://docs.ipfs.tech/install/ipfs-desktop/
2. Install and run the application
3. The IPFS daemon will start automatically
4. Verify it's running (look for green icon in system tray)

#### Option B: IPFS Command Line

1. **Initialize IPFS** (first time only):
   ```bash
   ipfs init
   ```

2. **Configure CORS** (allows web browser to connect):
   ```bash
   ipfs config --json API.HTTPHeaders.Access-Control-Allow-Origin '["*"]'
   ipfs config --json API.HTTPHeaders.Access-Control-Allow-Methods '["PUT", "POST", "GET"]'
   ```

3. **Start IPFS daemon**:
   ```bash
   ipfs daemon
   ```
   
   Keep this terminal running!

4. **Verify IPFS is working**:
   - Open http://localhost:5001/webui in your browser
   - You should see the IPFS Web UI

### Step 5: Compile and Deploy Smart Contracts

1. **Compile contracts**:
   ```bash
   truffle compile
   ```
   
   You should see output like:
   ```
   Compiling your contracts...
   ===========================
   > Compiling ./contracts/HealthRecordSystem.sol
   > Compiling ./contracts/Migrations.sol
   > Artifacts written to /path/to/build/contracts
   ```

2. **Deploy to Ganache**:
   ```bash
   truffle migrate --reset --network ganache
   ```
   
   Or if using development network:
   ```bash
   truffle migrate --reset
   ```
   
   Look for output showing:
   ```
   2_deploy_contracts.js
   =====================
   Deploying 'HealthRecordSystem'
   Contract address: 0x...
   ```

3. **Verify Deployment**:
   - Check the `build/contracts` folder exists
   - Check `.env` file has the CONTRACT_ADDRESS updated

### Step 6: Start the Application Server

1. **Start the server**:
   ```bash
   npm start
   ```
   
   Or for auto-reload during development:
   ```bash
   npm run dev
   ```

2. **Verify server is running**:
   - You should see:
     ```
     Server running on http://localhost:3000
     Loading smart contract...
     Contract loaded successfully at: 0x...
     ```

3. **Open the application**:
   - Navigate to http://localhost:3000 in your browser

## ✅ Verification Checklist

Before using the application, verify:

- [ ] Ganache is running (GUI or CLI)
- [ ] IPFS daemon is running
- [ ] MetaMask is installed and connected to Ganache network
- [ ] At least one Ganache account is imported to MetaMask
- [ ] Smart contracts are compiled (check `build/contracts` folder)
- [ ] Smart contracts are deployed (check console output)
- [ ] Server is running on http://localhost:3000
- [ ] Browser can access the application

## 🎯 Testing the Application

### Test 1: Register a Patient

1. Open http://localhost:3000
2. Click "Connect MetaMask"
3. Go to "Register" page
4. Click "Register as Patient"
5. Fill in all details
6. Click "Register"
7. Approve the MetaMask transaction
8. Wait for confirmation
9. Note your HH Number

### Test 2: Register a Doctor

1. Switch to a different MetaMask account
2. Go to "Register" page
3. Click "Register as Doctor"
4. Fill in professional details
5. Register and confirm transaction

### Test 3: Patient Uploads Record

1. Login as Patient
2. Go to "Upload Past Records"
3. Select a PDF file
4. Upload and confirm transaction
5. File is stored on IPFS
6. Hash is recorded on blockchain

### Test 4: Grant Doctor Access

1. As Patient, go to "Grant Permission"
2. Enter Doctor's HH Number
3. Confirm transaction
4. Doctor now has access to records

### Test 5: Doctor Views Patient

1. Login as Doctor
2. View "Patient List"
3. You should see the patient who granted access
4. View patient profile and records

## 🔧 Common Issues and Solutions

### Issue: MetaMask won't connect

**Solution**:
- Ensure MetaMask is on Ganache network
- Refresh the page
- Try disconnecting and reconnecting wallet
- Reset MetaMask account if needed (Settings → Advanced → Reset Account)

### Issue: Transaction fails with "insufficient funds"

**Solution**:
- Ensure your account has ETH from Ganache
- Check that you're using the correct account
- Refresh Ganache and redeploy if needed

### Issue: Contract not found error

**Solution**:
```bash
truffle migrate --reset --network ganache
npm start
```

### Issue: IPFS upload fails

**Solution**:
- Check IPFS daemon is running (`ipfs id`)
- Verify CORS is configured
- Restart IPFS daemon
- Check firewall settings

### Issue: "Error: Invalid JSON RPC response"

**Solution**:
- Ganache might not be running
- Check RPC URL in truffle-config.js matches Ganache
- Restart Ganache

### Issue: Page stuck loading

**Solution**:
- Open browser console (F12)
- Check for errors
- Ensure all services are running
- Clear browser cache and reload

## 🌐 Network Configuration Summary

| Service | URL | Port | Purpose |
|---------|-----|------|---------|
| Web App | http://localhost:3000 | 3000 | Application frontend |
| Ganache RPC | http://127.0.0.1:7545 | 7545 | Blockchain RPC |
| IPFS API | http://127.0.0.1:5001 | 5001 | IPFS HTTP API |
| IPFS Gateway | http://127.0.0.1:8080 | 8080 | IPFS file access |
| IPFS Swarm | - | 4001 | IPFS P2P |

## 📝 Accounts for Testing

You can use these Ganache accounts for different roles:

```
Account 1: Patient 1
Account 2: Patient 2
Account 3: Doctor 1
Account 4: Doctor 2
Account 5: Diagnostic Center
```

## 🎓 Next Steps

1. Explore all three user dashboards
2. Try uploading different file types
3. Test the permission system
4. View records on IPFS
5. Check transactions in Ganache
6. Modify smart contracts and redeploy
7. Customize the UI

## 💡 Tips

1. **Keep terminals organized**: Use different terminal windows for Ganache, IPFS, and the app server
2. **Use MetaMask labels**: Label your accounts for easy identification
3. **Check console logs**: Browser console (F12) shows helpful debugging info
4. **Monitor Ganache**: Watch transactions in real-time in Ganache GUI
5. **Test incrementally**: Test each feature before moving to the next

## 📚 Additional Resources

- Truffle Documentation: https://trufflesuite.com/docs/
- Web3.js Documentation: https://web3js.readthedocs.io/
- IPFS Documentation: https://docs.ipfs.tech/
- MetaMask Documentation: https://docs.metamask.io/
- Solidity Documentation: https://docs.soliditylang.org/

---

**Ready to build on blockchain! 🚀**

If you encounter any issues not covered here, check the README.md or create an issue on GitHub.
