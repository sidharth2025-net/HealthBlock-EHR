@echo off
echo ========================================
echo Blockchain EHR System - Quick Start
echo ========================================
echo.

echo Step 1: Installing dependencies...
call npm install
if %errorlevel% neq 0 (
    echo ERROR: Failed to install dependencies
    pause
    exit /b 1
)
echo Dependencies installed successfully!
echo.

echo Step 2: Please ensure the following are running:
echo   - Ganache on port 7545
echo   - IPFS daemon
echo.
echo Press any key to continue once they are running...
pause

echo.
echo Step 3: Compiling smart contracts...
call truffle compile
if %errorlevel% neq 0 (
    echo ERROR: Failed to compile contracts
    pause
    exit /b 1
)
echo Contracts compiled successfully!
echo.

echo Step 4: Deploying smart contracts...
call truffle migrate --reset --network ganache
if %errorlevel% neq 0 (
    echo ERROR: Failed to deploy contracts
    pause
    exit /b 1
)
echo Contracts deployed successfully!
echo.

echo Step 5: Starting the application server...
echo The application will be available at http://localhost:3000
echo.
call npm start
