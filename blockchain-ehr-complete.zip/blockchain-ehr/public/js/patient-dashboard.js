// Patient Dashboard JS
let currentUser;

document.addEventListener('DOMContentLoaded', async function() {
    await initWeb3();
    
    // Check if user is logged in
    const userSession = sessionStorage.getItem('currentUser');
    if (!userSession) {
        window.location.href = 'login.html';
        return;
    }
    
    currentUser = JSON.parse(userSession);
    if (currentUser.type !== 'patient') {
        alert('Access denied!');
        window.location.href = 'login.html';
        return;
    }
    
    // Display patient name
    document.getElementById('patientName').textContent = currentUser.data.fullName;
    
    // Setup logout
    document.getElementById('logoutBtn').addEventListener('click', logout);
    
    // Setup file input
    const fileInput = document.getElementById('fileInput');
    if (fileInput) {
        fileInput.addEventListener('change', function(e) {
            const fileName = e.target.files[0]?.name || 'No file chosen';
            document.getElementById('fileName').textContent = fileName;
        });
    }
    
    // Setup permission form
    const permissionForm = document.getElementById('permissionForm');
    if (permissionForm) {
        permissionForm.addEventListener('submit', async function(e) {
            e.preventDefault();
            await grantDoctorAccess();
        });
    }
});

function showSection(section) {
    // Hide all sections
    document.getElementById('profileSection').style.display = 'none';
    document.getElementById('recordsSection').style.display = 'none';
    document.getElementById('uploadSection').style.display = 'none';
    document.getElementById('permissionsSection').style.display = 'none';
    
    // Show selected section
    if (section === 'profile') {
        document.getElementById('profileSection').style.display = 'block';
        displayProfile();
    } else if (section === 'records') {
        document.getElementById('recordsSection').style.display = 'block';
        loadRecords();
    } else if (section === 'upload') {
        document.getElementById('uploadSection').style.display = 'block';
    } else if (section === 'permissions') {
        document.getElementById('permissionsSection').style.display = 'block';
    }
}

function hideSection() {
    document.getElementById('profileSection').style.display = 'none';
    document.getElementById('recordsSection').style.display = 'none';
    document.getElementById('uploadSection').style.display = 'none';
    document.getElementById('permissionsSection').style.display = 'none';
}

function displayProfile() {
    const profileDiv = document.getElementById('patientProfile');
    const data = currentUser.data;
    
    profileDiv.innerHTML = `
        <p><strong>Name:</strong> ${data.fullName}</p>
        <p><strong>DOB:</strong> ${data.dateOfBirth}</p>
        <p><strong>Gender:</strong> ${data.gender}</p>
        <p><strong>Blood Group:</strong> ${data.bloodGroup}</p>
        <p><strong>Address:</strong> ${data.residentialAddress}</p>
        <p><strong>Email:</strong> ${data.email}</p>
        <p><strong>Wallet Address:</strong> ${formatAddress(currentUser.address)}</p>
    `;
}

async function loadRecords() {
    const recordsList = document.getElementById('recordsList');
    recordsList.innerHTML = '<p>Loading records...</p>';
    
    try {
        const records = await getPatientRecords(currentUser.address);
        
        if (records.length === 0) {
            recordsList.innerHTML = '<p>No records found</p>';
            return;
        }
        
        let html = '';
        for (let i = 0; i < records.length; i++) {
            const recordId = records[i];
            html += `
                <div class="record-item">
                    <div>
                        <p><strong>Record:</strong> ${i + 1}</p>
                        <p><strong>Uploaded:</strong> ${new Date().toLocaleString()}</p>
                    </div>
                    <button class="btn-primary" onclick="viewRecord('${recordId}')">View</button>
                </div>
            `;
        }
        
        recordsList.innerHTML = html;
    } catch (error) {
        console.error('Error loading records:', error);
        recordsList.innerHTML = '<p>Error loading records</p>';
    }
}

async function uploadRecord() {
    const fileInput = document.getElementById('fileInput');
    const file = fileInput.files[0];
    
    if (!file) {
        alert('Please select a file');
        return;
    }
    
    try {
        showLoading('Uploading to IPFS...');
        
        // Upload to IPFS
        const ipfsResult = await uploadToIPFS(file);
        
        // Add to blockchain
        const recordId = generateRecordId();
        await addMedicalRecord(recordId, currentUser.address, ipfsResult.hash, 'past-record');
        
        // Store record info in localStorage
        const records = JSON.parse(localStorage.getItem('records') || '{}');
        if (!records[currentUser.address]) {
            records[currentUser.address] = [];
        }
        records[currentUser.address].push({
            id: recordId,
            ipfsHash: ipfsResult.hash,
            fileName: file.name,
            uploadDate: new Date().toISOString()
        });
        localStorage.setItem('records', JSON.stringify(records));
        
        hideLoading();
        alert('Record uploaded successfully!');
        hideSection();
        fileInput.value = '';
        document.getElementById('fileName').textContent = 'No file chosen';
        
    } catch (error) {
        hideLoading();
        console.error('Upload error:', error);
        alert('Failed to upload record: ' + error.message);
    }
}

async function viewRecord(recordId) {
    const records = JSON.parse(localStorage.getItem('records') || '{}');
    const userRecords = records[currentUser.address] || [];
    const record = userRecords.find(r => r.id === recordId);
    
    if (record) {
        const url = `http://127.0.0.1:8080/ipfs/${record.ipfsHash}`;
        window.open(url, '_blank');
    } else {
        alert('Record not found');
    }
}

async function grantDoctorAccess() {
    const doctorHH = document.getElementById('doctorHHNumber').value;
    
    try {
        // Get doctor info
        const users = JSON.parse(localStorage.getItem('users') || '{}');
        const doctor = users[doctorHH];
        
        if (!doctor || doctor.type !== 'doctor') {
            alert('Doctor not found!');
            return;
        }
        
        showLoading('Granting access on blockchain...');
        
        // Grant access on blockchain
        await grantAccess(doctor.address);
        
        // Store permission locally
        const permissions = JSON.parse(localStorage.getItem('permissions') || '{}');
        const key = `${currentUser.address}_${doctor.address}`;
        permissions[key] = {
            patient: currentUser.address,
            doctor: doctor.address,
            doctorName: doctor.data.fullName,
            grantedAt: new Date().toISOString()
        };
        localStorage.setItem('permissions', JSON.stringify(permissions));
        
        hideLoading();
        alert('Access granted successfully!');
        hideSection();
        document.getElementById('doctorHHNumber').value = '';
        
    } catch (error) {
        hideLoading();
        console.error('Error granting access:', error);
        alert('Failed to grant access: ' + error.message);
    }
}

function logout() {
    sessionStorage.removeItem('currentUser');
    window.location.href = 'index.html';
}

function showLoading(message) {
    const overlay = document.createElement('div');
    overlay.id = 'loadingOverlay';
    overlay.style.cssText = `
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0, 0, 0, 0.8);
        display: flex;
        justify-content: center;
        align-items: center;
        z-index: 9999;
    `;
    overlay.innerHTML = `
        <div style="text-align: center; color: white;">
            <div class="loading"></div>
            <p style="margin-top: 1rem;">${message}</p>
        </div>
    `;
    document.body.appendChild(overlay);
}

function hideLoading() {
    const overlay = document.getElementById('loadingOverlay');
    if (overlay) {
        overlay.remove();
    }
}
