// Web3 and Contract Handler
let web3;
let account;
let contract;
let contractAddress;
let contractABI;

// Initialize Web3
async function initWeb3() {
    if (typeof window.ethereum !== 'undefined') {
        try {
            web3 = new Web3(window.ethereum);
            console.log('Web3 initialized successfully');
            return true;
        } catch (error) {
            console.error('Error initializing Web3:', error);
            return false;
        }
    } else {
        alert('Please install MetaMask to use this application!');
        return false;
    }
}

// Connect to MetaMask
async function connectWallet() {
    try {
        const accounts = await window.ethereum.request({ 
            method: 'eth_requestAccounts' 
        });
        account = accounts[0];
        console.log('Connected account:', account);
        
        // Load contract
        await loadContract();
        
        return account;
    } catch (error) {
        console.error('Error connecting to MetaMask:', error);
        alert('Failed to connect to MetaMask');
        return null;
    }
}

// Load Smart Contract
async function loadContract() {
    try {
        const response = await fetch('/api/contract');
        const data = await response.json();
        
        contractAddress = data.address;
        contractABI = data.abi;
        
        if (contractAddress && contractABI) {
            contract = new web3.eth.Contract(contractABI, contractAddress);
            console.log('Contract loaded at:', contractAddress);
            return true;
        } else {
            console.error('Contract not deployed');
            return false;
        }
    } catch (error) {
        console.error('Error loading contract:', error);
        return false;
    }
}

// Get current account
async function getCurrentAccount() {
    if (!account) {
        const accounts = await web3.eth.getAccounts();
        account = accounts[0];
    }
    return account;
}

// Register Doctor on Blockchain
async function registerDoctorOnChain(doctorData) {
    try {
        const currentAccount = await getCurrentAccount();
        
        const result = await contract.methods.registerDoctor(
            doctorData.fullName,
            doctorData.hospitalName,
            doctorData.hospitalLocation,
            doctorData.dateOfBirth,
            doctorData.gender,
            doctorData.email,
            doctorData.hhNumber,
            doctorData.specialization,
            doctorData.department,
            doctorData.designation,
            parseInt(doctorData.workExperience)
        ).send({ from: currentAccount });
        
        console.log('Doctor registered:', result);
        return result;
    } catch (error) {
        console.error('Error registering doctor:', error);
        throw error;
    }
}

// Register Patient on Blockchain
async function registerPatientOnChain(patientData) {
    try {
        const currentAccount = await getCurrentAccount();
        
        const result = await contract.methods.registerPatient(
            patientData.fullName,
            patientData.dateOfBirth,
            patientData.gender,
            patientData.bloodGroup,
            patientData.residentialAddress,
            patientData.email
        ).send({ from: currentAccount });
        
        console.log('Patient registered:', result);
        return result;
    } catch (error) {
        console.error('Error registering patient:', error);
        throw error;
    }
}

// Register Diagnostic Center on Blockchain
async function registerDiagnosticOnChain(diagnosticData) {
    try {
        const currentAccount = await getCurrentAccount();
        
        const result = await contract.methods.registerDiagnosticCenter(
            diagnosticData.centerName,
            diagnosticData.hospitalName,
            diagnosticData.location,
            diagnosticData.email,
            diagnosticData.hhNumber
        ).send({ from: currentAccount });
        
        console.log('Diagnostic center registered:', result);
        return result;
    } catch (error) {
        console.error('Error registering diagnostic center:', error);
        throw error;
    }
}

// Get Doctor Information
async function getDoctor(address) {
    try {
        const doctor = await contract.methods.getDoctor(address).call();
        return doctor;
    } catch (error) {
        console.error('Error getting doctor:', error);
        return null;
    }
}

// Get Patient Information
async function getPatient(address) {
    try {
        const patient = await contract.methods.getPatient(address).call();
        return patient;
    } catch (error) {
        console.error('Error getting patient:', error);
        return null;
    }
}

// Get Diagnostic Center Information
async function getDiagnosticCenter(address) {
    try {
        const diagnostic = await contract.methods.getDiagnosticCenter(address).call();
        return diagnostic;
    } catch (error) {
        console.error('Error getting diagnostic center:', error);
        return null;
    }
}

// Add Medical Record
async function addMedicalRecord(recordId, patientAddress, ipfsHash, recordType) {
    try {
        const currentAccount = await getCurrentAccount();
        
        const result = await contract.methods.addMedicalRecord(
            recordId,
            patientAddress,
            ipfsHash,
            recordType
        ).send({ from: currentAccount });
        
        console.log('Medical record added:', result);
        return result;
    } catch (error) {
        console.error('Error adding medical record:', error);
        throw error;
    }
}

// Add Consultation
async function addConsultation(recordId, patientAddress, patientName, diagnosis, prescription) {
    try {
        const currentAccount = await getCurrentAccount();
        
        const result = await contract.methods.addConsultation(
            recordId,
            patientAddress,
            patientName,
            diagnosis,
            prescription
        ).send({ from: currentAccount });
        
        console.log('Consultation added:', result);
        return result;
    } catch (error) {
        console.error('Error adding consultation:', error);
        throw error;
    }
}

// Add Lab Report
async function addLabReport(recordId, patientAddress, patientName, doctorName, age, gender, bloodGroup, reportIpfsHash) {
    try {
        const currentAccount = await getCurrentAccount();
        
        const result = await contract.methods.addLabReport(
            recordId,
            patientAddress,
            patientName,
            doctorName,
            age,
            gender,
            bloodGroup,
            reportIpfsHash
        ).send({ from: currentAccount });
        
        console.log('Lab report added:', result);
        return result;
    } catch (error) {
        console.error('Error adding lab report:', error);
        throw error;
    }
}

// Grant Access to Doctor
async function grantAccess(doctorAddress) {
    try {
        const currentAccount = await getCurrentAccount();
        
        const result = await contract.methods.grantAccess(doctorAddress)
            .send({ from: currentAccount });
        
        console.log('Access granted:', result);
        return result;
    } catch (error) {
        console.error('Error granting access:', error);
        throw error;
    }
}

// Get Patient Records
async function getPatientRecords(patientAddress) {
    try {
        const records = await contract.methods.getPatientRecords(patientAddress).call();
        return records;
    } catch (error) {
        console.error('Error getting patient records:', error);
        return [];
    }
}

// Upload File to IPFS
async function uploadToIPFS(file) {
    try {
        const formData = new FormData();
        formData.append('file', file);
        
        const response = await fetch('/api/ipfs/upload', {
            method: 'POST',
            body: formData
        });
        
        const data = await response.json();
        console.log('File uploaded to IPFS:', data);
        return data;
    } catch (error) {
        console.error('Error uploading to IPFS:', error);
        throw error;
    }
}

// Generate Random Record ID
function generateRecordId() {
    return 'EHR' + Date.now().toString(36) + Math.random().toString(36).substr(2, 9);
}

// Format Address (Shorten)
function formatAddress(address) {
    if (!address) return '';
    return address.substring(0, 6) + '...' + address.substring(address.length - 4);
}

// Listen to Account Changes
if (typeof window.ethereum !== 'undefined') {
    window.ethereum.on('accountsChanged', function (accounts) {
        account = accounts[0];
        console.log('Account changed to:', account);
        // Reload page or update UI
        location.reload();
    });

    window.ethereum.on('chainChanged', function (chainId) {
        console.log('Chain changed to:', chainId);
        // Reload page
        location.reload();
    });
}
