// Registration Page JS
document.addEventListener('DOMContentLoaded', async function() {
    await initWeb3();
    
    // Auto-fill wallet addresses when forms are shown
    setupFormListeners();
});

function showRegistration(type) {
    // Hide all forms
    document.getElementById('doctorForm').style.display = 'none';
    document.getElementById('patientForm').style.display = 'none';
    document.getElementById('diagnosticForm').style.display = 'none';
    
    // Show selected form
    if (type === 'doctor') {
        document.getElementById('doctorForm').style.display = 'block';
        fillWalletAddress('doctorWallet');
    } else if (type === 'patient') {
        document.getElementById('patientForm').style.display = 'block';
        fillWalletAddress('patientWallet');
    } else if (type === 'diagnostic') {
        document.getElementById('diagnosticForm').style.display = 'block';
        fillWalletAddress('diagnosticWallet');
    }
}

function closeForm() {
    document.getElementById('doctorForm').style.display = 'none';
    document.getElementById('patientForm').style.display = 'none';
    document.getElementById('diagnosticForm').style.display = 'none';
}

async function fillWalletAddress(fieldId) {
    const address = await connectWallet();
    if (address) {
        document.getElementById(fieldId).value = address;
    }
}

function setupFormListeners() {
    // Doctor Registration
    const doctorForm = document.getElementById('doctorRegistrationForm');
    if (doctorForm) {
        doctorForm.addEventListener('submit', async function(e) {
            e.preventDefault();
            await registerDoctor();
        });
    }
    
    // Patient Registration
    const patientForm = document.getElementById('patientRegistrationForm');
    if (patientForm) {
        patientForm.addEventListener('submit', async function(e) {
            e.preventDefault();
            await registerPatient();
        });
    }
    
    // Diagnostic Registration
    const diagnosticForm = document.getElementById('diagnosticRegistrationForm');
    if (diagnosticForm) {
        diagnosticForm.addEventListener('submit', async function(e) {
            e.preventDefault();
            await registerDiagnostic();
        });
    }
}

async function registerDoctor() {
    try {
        const password = document.getElementById('doctorPassword').value;
        const confirmPassword = document.getElementById('doctorConfirmPassword').value;
        
        if (password !== confirmPassword) {
            alert('Passwords do not match!');
            return;
        }
        
        const doctorData = {
            walletAddress: document.getElementById('doctorWallet').value,
            fullName: document.getElementById('doctorName').value,
            hospitalName: document.getElementById('doctorHospital').value,
            hospitalLocation: document.getElementById('doctorLocation').value,
            dateOfBirth: document.getElementById('doctorDob').value,
            gender: document.getElementById('doctorGender').value,
            email: document.getElementById('doctorEmail').value,
            hhNumber: document.getElementById('doctorHH').value,
            specialization: document.getElementById('doctorSpecialization').value,
            department: document.getElementById('doctorDepartment').value,
            designation: document.getElementById('doctorDesignation').value,
            workExperience: document.getElementById('doctorExperience').value
        };
        
        // Show loading
        showLoading('Registering doctor on blockchain...');
        
        // Register on blockchain
        await registerDoctorOnChain(doctorData);
        
        // Store in localStorage (in real app, use secure backend)
        const users = JSON.parse(localStorage.getItem('users') || '{}');
        users[doctorData.hhNumber] = {
            type: 'doctor',
            password: password,
            address: doctorData.walletAddress,
            data: doctorData
        };
        localStorage.setItem('users', JSON.stringify(users));
        
        hideLoading();
        alert('Doctor registered successfully!');
        window.location.href = 'login.html';
        
    } catch (error) {
        hideLoading();
        console.error('Registration error:', error);
        alert('Failed to register doctor: ' + error.message);
    }
}

async function registerPatient() {
    try {
        const password = document.getElementById('patientPassword').value;
        const confirmPassword = document.getElementById('patientConfirmPassword').value;
        
        if (password !== confirmPassword) {
            alert('Passwords do not match!');
            return;
        }
        
        const patientData = {
            walletAddress: document.getElementById('patientWallet').value,
            fullName: document.getElementById('patientName').value,
            dateOfBirth: document.getElementById('patientDob').value,
            gender: document.getElementById('patientGender').value,
            bloodGroup: document.getElementById('patientBloodGroup').value,
            residentialAddress: document.getElementById('patientAddress').value,
            email: document.getElementById('patientEmail').value
        };
        
        // Generate HH Number for patient
        const hhNumber = 'P' + Date.now();
        
        showLoading('Registering patient on blockchain...');
        
        await registerPatientOnChain(patientData);
        
        const users = JSON.parse(localStorage.getItem('users') || '{}');
        users[hhNumber] = {
            type: 'patient',
            password: password,
            address: patientData.walletAddress,
            data: patientData
        };
        localStorage.setItem('users', JSON.stringify(users));
        
        hideLoading();
        alert('Patient registered successfully! Your HH Number is: ' + hhNumber);
        window.location.href = 'login.html';
        
    } catch (error) {
        hideLoading();
        console.error('Registration error:', error);
        alert('Failed to register patient: ' + error.message);
    }
}

async function registerDiagnostic() {
    try {
        const password = document.getElementById('diagnosticPassword').value;
        const confirmPassword = document.getElementById('diagnosticConfirmPassword').value;
        
        if (password !== confirmPassword) {
            alert('Passwords do not match!');
            return;
        }
        
        const diagnosticData = {
            walletAddress: document.getElementById('diagnosticWallet').value,
            centerName: document.getElementById('diagnosticName').value,
            hospitalName: document.getElementById('diagnosticHospital').value,
            location: document.getElementById('diagnosticLocation').value,
            email: document.getElementById('diagnosticEmail').value,
            hhNumber: document.getElementById('diagnosticHH').value
        };
        
        showLoading('Registering diagnostic center on blockchain...');
        
        await registerDiagnosticOnChain(diagnosticData);
        
        const users = JSON.parse(localStorage.getItem('users') || '{}');
        users[diagnosticData.hhNumber] = {
            type: 'diagnostic',
            password: password,
            address: diagnosticData.walletAddress,
            data: diagnosticData
        };
        localStorage.setItem('users', JSON.stringify(users));
        
        hideLoading();
        alert('Diagnostic center registered successfully!');
        window.location.href = 'login.html';
        
    } catch (error) {
        hideLoading();
        console.error('Registration error:', error);
        alert('Failed to register diagnostic center: ' + error.message);
    }
}

function showLoading(message) {
    const overlay = document.createElement('div');
    overlay.id = 'loadingOverlay';
    overlay.style.cssText = `
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0, 0, 0, 0.8);
        display: flex;
        justify-content: center;
        align-items: center;
        z-index: 9999;
    `;
    overlay.innerHTML = `
        <div style="text-align: center; color: white;">
            <div class="loading"></div>
            <p style="margin-top: 1rem;">${message}</p>
        </div>
    `;
    document.body.appendChild(overlay);
}

function hideLoading() {
    const overlay = document.getElementById('loadingOverlay');
    if (overlay) {
        overlay.remove();
    }
}
