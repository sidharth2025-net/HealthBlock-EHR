// Diagnostic Dashboard JS
let currentUser;

document.addEventListener('DOMContentLoaded', async function() {
    await initWeb3();
    
    // Check if user is logged in
    const userSession = sessionStorage.getItem('currentUser');
    if (!userSession) {
        window.location.href = 'login.html';
        return;
    }
    
    currentUser = JSON.parse(userSession);
    if (currentUser.type !== 'diagnostic') {
        alert('Access denied!');
        window.location.href = 'login.html';
        return;
    }
    
    // Display diagnostic center name
    document.getElementById('diagnosticName').textContent = currentUser.data.centerName;
    
    // Setup logout
    document.getElementById('logoutBtn').addEventListener('click', logout);
    
    // Setup file input
    const reportFile = document.getElementById('reportFile');
    if (reportFile) {
        reportFile.addEventListener('change', function(e) {
            const fileName = e.target.files[0]?.name || 'No file chosen';
            document.getElementById('reportFileName').textContent = fileName;
        });
    }
    
    // Setup form
    const labReportForm = document.getElementById('labReportForm');
    if (labReportForm) {
        labReportForm.addEventListener('submit', async function(e) {
            e.preventDefault();
            await createLabReport();
        });
    }
    
    // Auto-fill diagnostic wallet
    if (document.getElementById('reportDiagnosticWallet')) {
        document.getElementById('reportDiagnosticWallet').value = currentUser.address;
    }
});

function showSection(section) {
    // Hide all sections
    document.getElementById('profileSection').style.display = 'none';
    document.getElementById('createReportSection').style.display = 'none';
    
    // Show selected section
    if (section === 'profile') {
        document.getElementById('profileSection').style.display = 'block';
        displayProfile();
    } else if (section === 'createReport') {
        document.getElementById('createReportSection').style.display = 'block';
        // Generate new record ID
        document.getElementById('reportRecordId').value = generateRecordId();
        document.getElementById('reportDiagnosticWallet').value = currentUser.address;
    }
}

function hideSection() {
    document.getElementById('profileSection').style.display = 'none';
    document.getElementById('createReportSection').style.display = 'none';
}

function displayProfile() {
    const profileDiv = document.getElementById('diagnosticProfile');
    const data = currentUser.data;
    
    profileDiv.innerHTML = `
        <p><strong>Center Name:</strong> ${data.centerName}</p>
        <p><strong>Hospital:</strong> ${data.hospitalName}</p>
        <p><strong>Location:</strong> ${data.location}</p>
        <p><strong>Email:</strong> ${data.email}</p>
        <p><strong>HH Number:</strong> ${data.hhNumber}</p>
        <p><strong>Wallet Address:</strong> ${formatAddress(currentUser.address)}</p>
    `;
}

async function createLabReport() {
    try {
        const reportFile = document.getElementById('reportFile');
        const file = reportFile.files[0];
        
        if (!file) {
            alert('Please select a report file');
            return;
        }
        
        const recordId = document.getElementById('reportRecordId').value;
        const doctorName = document.getElementById('reportDoctorName').value;
        const patientName = document.getElementById('reportPatientName').value;
        const age = parseInt(document.getElementById('reportAge').value);
        const gender = document.getElementById('reportGender').value;
        const bloodGroup = document.getElementById('reportBloodGroup').value;
        const patientWallet = document.getElementById('reportPatientWallet').value;
        
        // Validate patient wallet
        if (!web3.utils.isAddress(patientWallet)) {
            alert('Invalid patient wallet address');
            return;
        }
        
        showLoading('Uploading report to IPFS...');
        
        // Upload to IPFS
        const ipfsResult = await uploadToIPFS(file);
        
        showLoading('Creating lab report on blockchain...');
        
        // Add lab report to blockchain
        await addLabReport(
            recordId,
            patientWallet,
            patientName,
            doctorName,
            age,
            gender,
            bloodGroup,
            ipfsResult.hash
        );
        
        // Store report info locally
        const reports = JSON.parse(localStorage.getItem('labReports') || '{}');
        if (!reports[patientWallet]) {
            reports[patientWallet] = [];
        }
        reports[patientWallet].push({
            id: recordId,
            patientName: patientName,
            doctorName: doctorName,
            age: age,
            gender: gender,
            bloodGroup: bloodGroup,
            ipfsHash: ipfsResult.hash,
            fileName: file.name,
            diagnosticCenter: currentUser.data.centerName,
            date: new Date().toISOString()
        });
        localStorage.setItem('labReports', JSON.stringify(reports));
        
        hideLoading();
        alert('Lab report created successfully!');
        
        // Reset form
        document.getElementById('labReportForm').reset();
        document.getElementById('reportRecordId').value = generateRecordId();
        document.getElementById('reportDiagnosticWallet').value = currentUser.address;
        document.getElementById('reportFileName').textContent = 'No file chosen';
        
    } catch (error) {
        hideLoading();
        console.error('Error creating lab report:', error);
        alert('Failed to create lab report: ' + error.message);
    }
}

async function uploadReportOnly() {
    const reportFile = document.getElementById('reportFile');
    const file = reportFile.files[0];
    
    if (!file) {
        alert('Please select a file');
        return;
    }
    
    try {
        showLoading('Uploading report to IPFS...');
        
        const ipfsResult = await uploadToIPFS(file);
        
        hideLoading();
        alert(`Report uploaded successfully!\nIPFS Hash: ${ipfsResult.hash}\nURL: ${ipfsResult.url}`);
        
        // Open in new tab
        window.open(ipfsResult.url, '_blank');
        
    } catch (error) {
        hideLoading();
        console.error('Upload error:', error);
        alert('Failed to upload report: ' + error.message);
    }
}

function logout() {
    sessionStorage.removeItem('currentUser');
    window.location.href = 'index.html';
}

function showLoading(message) {
    const overlay = document.createElement('div');
    overlay.id = 'loadingOverlay';
    overlay.style.cssText = `
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0, 0, 0, 0.8);
        display: flex;
        justify-content: center;
        align-items: center;
        z-index: 9999;
    `;
    overlay.innerHTML = `
        <div style="text-align: center; color: white;">
            <div class="loading"></div>
            <p style="margin-top: 1rem;">${message}</p>
        </div>
    `;
    document.body.appendChild(overlay);
}

function hideLoading() {
    const overlay = document.getElementById('loadingOverlay');
    if (overlay) {
        overlay.remove();
    }
}
