// Doctor Dashboard JS
let currentUser;
let selectedPatient;

document.addEventListener('DOMContentLoaded', async function() {
    await initWeb3();
    
    // Check if user is logged in
    const userSession = sessionStorage.getItem('currentUser');
    if (!userSession) {
        window.location.href = 'login.html';
        return;
    }
    
    currentUser = JSON.parse(userSession);
    if (currentUser.type !== 'doctor') {
        alert('Access denied!');
        window.location.href = 'login.html';
        return;
    }
    
    // Display doctor name
    document.getElementById('doctorName').textContent = currentUser.data.fullName;
    
    // Setup logout
    document.getElementById('logoutBtn').addEventListener('click', logout);
    
    // Setup consultation form
    const consultationForm = document.getElementById('consultationForm');
    if (consultationForm) {
        consultationForm.addEventListener('submit', async function(e) {
            e.preventDefault();
            await createConsultation();
        });
    }
});

function showSection(section) {
    // Hide all sections
    document.getElementById('profileSection').style.display = 'none';
    document.getElementById('patientsSection').style.display = 'none';
    document.getElementById('patientDetailSection').style.display = 'none';
    document.getElementById('consultationSection').style.display = 'none';
    
    // Show selected section
    if (section === 'profile') {
        document.getElementById('profileSection').style.display = 'block';
        displayProfile();
    } else if (section === 'patients') {
        document.getElementById('patientsSection').style.display = 'block';
        loadPatients();
    }
}

function hideSection() {
    document.getElementById('profileSection').style.display = 'none';
    document.getElementById('patientsSection').style.display = 'none';
    document.getElementById('patientDetailSection').style.display = 'none';
    document.getElementById('consultationSection').style.display = 'none';
}

function displayProfile() {
    const profileDiv = document.getElementById('doctorProfile');
    const data = currentUser.data;
    
    profileDiv.innerHTML = `
        <p><strong>Name:</strong> ${data.fullName}</p>
        <p><strong>Hospital:</strong> ${data.hospitalName}</p>
        <p><strong>Location:</strong> ${data.hospitalLocation}</p>
        <p><strong>Specialization:</strong> ${data.specialization}</p>
        <p><strong>Department:</strong> ${data.department}</p>
        <p><strong>Designation:</strong> ${data.designation}</p>
        <p><strong>Experience:</strong> ${data.workExperience} years</p>
        <p><strong>Email:</strong> ${data.email}</p>
        <p><strong>HH Number:</strong> ${data.hhNumber}</p>
        <p><strong>Wallet Address:</strong> ${formatAddress(currentUser.address)}</p>
    `;
}

async function loadPatients() {
    const patientsList = document.getElementById('patientsList');
    patientsList.innerHTML = '<p>Loading patients...</p>';
    
    try {
        // Get all permissions
        const permissions = JSON.parse(localStorage.getItem('permissions') || '{}');
        const doctorPatients = Object.values(permissions).filter(
            p => p.doctor.toLowerCase() === currentUser.address.toLowerCase()
        );
        
        if (doctorPatients.length === 0) {
            patientsList.innerHTML = '<p>No patients have granted you access yet</p>';
            return;
        }
        
        // Get patient data
        const users = JSON.parse(localStorage.getItem('users') || '{}');
        let html = '';
        
        for (const permission of doctorPatients) {
            // Find patient in users
            const patientUser = Object.entries(users).find(
                ([_, u]) => u.address.toLowerCase() === permission.patient.toLowerCase() && u.type === 'patient'
            );
            
            if (patientUser) {
                const [hhNumber, userData] = patientUser;
                html += `
                    <div class="patient-item">
                        <div>
                            <p><strong>Patient:</strong> ${userData.data.fullName}</p>
                            <p><strong>Name:</strong> ${userData.data.fullName}</p>
                        </div>
                        <div>
                            <button class="btn-primary" onclick='viewPatient(${JSON.stringify(userData)})'>View</button>
                            <button class="btn-secondary" onclick="removePatient('${permission.patient}')">Remove</button>
                        </div>
                    </div>
                `;
            }
        }
        
        patientsList.innerHTML = html || '<p>No patients found</p>';
    } catch (error) {
        console.error('Error loading patients:', error);
        patientsList.innerHTML = '<p>Error loading patients</p>';
    }
}

function viewPatient(patientData) {
    selectedPatient = patientData;
    
    // Hide patients list, show patient detail
    document.getElementById('patientsSection').style.display = 'none';
    document.getElementById('patientDetailSection').style.display = 'block';
    
    const detailDiv = document.getElementById('patientDetail');
    const data = patientData.data;
    
    detailDiv.innerHTML = `
        <p><strong>Name:</strong> ${data.fullName}</p>
        <p><strong>DOB:</strong> ${data.dateOfBirth}</p>
        <p><strong>Gender:</strong> ${data.gender}</p>
        <p><strong>Blood Group:</strong> ${data.bloodGroup}</p>
        <p><strong>Address:</strong> ${data.residentialAddress}</p>
        <p><strong>Email:</strong> ${data.email}</p>
    `;
}

function backToPatientList() {
    document.getElementById('patientDetailSection').style.display = 'none';
    document.getElementById('patientsSection').style.display = 'block';
}

async function viewPatientRecords() {
    if (!selectedPatient) return;
    
    try {
        const records = await getPatientRecords(selectedPatient.address);
        
        if (records.length === 0) {
            alert('No records available for this patient');
            return;
        }
        
        // Get records from localStorage
        const allRecords = JSON.parse(localStorage.getItem('records') || '{}');
        const patientRecords = allRecords[selectedPatient.address] || [];
        
        if (patientRecords.length > 0) {
            const record = patientRecords[0];
            const url = `http://127.0.0.1:8080/ipfs/${record.ipfsHash}`;
            window.open(url, '_blank');
        } else {
            alert('No records available');
        }
    } catch (error) {
        console.error('Error viewing records:', error);
        alert('Failed to load records');
    }
}

function showConsultationForm() {
    if (!selectedPatient) return;
    
    document.getElementById('patientDetailSection').style.display = 'none';
    document.getElementById('consultationSection').style.display = 'block';
    
    // Fill form
    document.getElementById('consultRecordId').value = generateRecordId();
    document.getElementById('consultPatientName').value = selectedPatient.data.fullName;
    document.getElementById('consultDoctorWallet').value = currentUser.address;
    document.getElementById('consultGender').value = selectedPatient.data.gender;
}

function hideConsultationForm() {
    document.getElementById('consultationSection').style.display = 'none';
    document.getElementById('patientDetailSection').style.display = 'block';
}

async function createConsultation() {
    try {
        const recordId = document.getElementById('consultRecordId').value;
        const patientName = document.getElementById('consultPatientName').value;
        const diagnosis = document.getElementById('consultDiagnosis').value;
        const prescription = document.getElementById('consultPrescription').value;
        
        showLoading('Creating consultation record on blockchain...');
        
        // Add consultation to blockchain
        await addConsultation(
            recordId,
            selectedPatient.address,
            patientName,
            diagnosis,
            prescription
        );
        
        // Store consultation locally
        const consultations = JSON.parse(localStorage.getItem('consultations') || '{}');
        if (!consultations[selectedPatient.address]) {
            consultations[selectedPatient.address] = [];
        }
        consultations[selectedPatient.address].push({
            id: recordId,
            patientName: patientName,
            doctorName: currentUser.data.fullName,
            diagnosis: diagnosis,
            prescription: prescription,
            date: new Date().toISOString()
        });
        localStorage.setItem('consultations', JSON.stringify(consultations));
        
        hideLoading();
        alert('Consultation record created successfully!');
        
        // Reset form
        document.getElementById('consultDiagnosis').value = '';
        document.getElementById('consultPrescription').value = '';
        hideConsultationForm();
        
    } catch (error) {
        hideLoading();
        console.error('Error creating consultation:', error);
        alert('Failed to create consultation: ' + error.message);
    }
}

function removePatient(patientAddress) {
    if (confirm('Are you sure you want to remove access to this patient?')) {
        // In a real app, this would revoke access on the blockchain
        alert('Patient access removed');
        loadPatients();
    }
}

function logout() {
    sessionStorage.removeItem('currentUser');
    window.location.href = 'index.html';
}

function showLoading(message) {
    const overlay = document.createElement('div');
    overlay.id = 'loadingOverlay';
    overlay.style.cssText = `
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0, 0, 0, 0.8);
        display: flex;
        justify-content: center;
        align-items: center;
        z-index: 9999;
    `;
    overlay.innerHTML = `
        <div style="text-align: center; color: white;">
            <div class="loading"></div>
            <p style="margin-top: 1rem;">${message}</p>
        </div>
    `;
    document.body.appendChild(overlay);
}

function hideLoading() {
    const overlay = document.getElementById('loadingOverlay');
    if (overlay) {
        overlay.remove();
    }
}
