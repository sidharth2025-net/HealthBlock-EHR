// Login Page JS
document.addEventListener('DOMContentLoaded', async function() {
    await initWeb3();
    setupLoginForms();
});

function showLogin(type) {
    // Hide all forms
    document.getElementById('doctorLogin').style.display = 'none';
    document.getElementById('patientLogin').style.display = 'none';
    document.getElementById('diagnosticLogin').style.display = 'none';
    
    // Show selected form
    if (type === 'doctor') {
        document.getElementById('doctorLogin').style.display = 'block';
    } else if (type === 'patient') {
        document.getElementById('patientLogin').style.display = 'block';
    } else if (type === 'diagnostic') {
        document.getElementById('diagnosticLogin').style.display = 'block';
    }
}

function closeLoginForm() {
    document.getElementById('doctorLogin').style.display = 'none';
    document.getElementById('patientLogin').style.display = 'none';
    document.getElementById('diagnosticLogin').style.display = 'none';
}

function setupLoginForms() {
    // Doctor Login
    const doctorLoginForm = document.getElementById('doctorLoginForm');
    if (doctorLoginForm) {
        doctorLoginForm.addEventListener('submit', async function(e) {
            e.preventDefault();
            await loginUser('doctor');
        });
    }
    
    // Patient Login
    const patientLoginForm = document.getElementById('patientLoginForm');
    if (patientLoginForm) {
        patientLoginForm.addEventListener('submit', async function(e) {
            e.preventDefault();
            await loginUser('patient');
        });
    }
    
    // Diagnostic Login
    const diagnosticLoginForm = document.getElementById('diagnosticLoginForm');
    if (diagnosticLoginForm) {
        diagnosticLoginForm.addEventListener('submit', async function(e) {
            e.preventDefault();
            await loginUser('diagnostic');
        });
    }
}

async function loginUser(type) {
    try {
        let hhNumber, password;
        
        if (type === 'doctor') {
            hhNumber = document.getElementById('doctorLoginHH').value;
            password = document.getElementById('doctorLoginPassword').value;
        } else if (type === 'patient') {
            hhNumber = document.getElementById('patientLoginHH').value;
            password = document.getElementById('patientLoginPassword').value;
        } else if (type === 'diagnostic') {
            hhNumber = document.getElementById('diagnosticLoginHH').value;
            password = document.getElementById('diagnosticLoginPassword').value;
        }
        
        // Get users from localStorage
        const users = JSON.parse(localStorage.getItem('users') || '{}');
        const user = users[hhNumber];
        
        if (!user) {
            alert('User not found! Please register first.');
            return;
        }
        
        if (user.type !== type) {
            alert(`This HH Number is registered as ${user.type}, not ${type}`);
            return;
        }
        
        if (user.password !== password) {
            alert('Incorrect password!');
            return;
        }
        
        // Connect wallet
        const address = await connectWallet();
        if (!address) {
            alert('Please connect your wallet');
            return;
        }
        
        if (address.toLowerCase() !== user.address.toLowerCase()) {
            alert('Wallet address does not match registered address!');
            return;
        }
        
        // Store session
        sessionStorage.setItem('currentUser', JSON.stringify({
            type: type,
            hhNumber: hhNumber,
            address: address,
            data: user.data
        }));
        
        // Redirect to appropriate dashboard
        if (type === 'doctor') {
            window.location.href = 'doctor-dashboard.html';
        } else if (type === 'patient') {
            window.location.href = 'patient-dashboard.html';
        } else if (type === 'diagnostic') {
            window.location.href = 'diagnostic-dashboard.html';
        }
        
    } catch (error) {
        console.error('Login error:', error);
        alert('Login failed: ' + error.message);
    }
}
