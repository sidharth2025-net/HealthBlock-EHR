// Main JS for Home Page
document.addEventListener('DOMContentLoaded', async function() {
    // Initialize Web3
    await initWeb3();
    
    // Check if already connected
    checkConnection();
    
    // Connect Wallet Button
    const connectBtn = document.getElementById('connectWallet');
    if (connectBtn) {
        connectBtn.addEventListener('click', async function() {
            const address = await connectWallet();
            if (address) {
                updateWalletInfo(address);
            }
        });
    }
});

async function checkConnection() {
    if (typeof window.ethereum !== 'undefined') {
        const accounts = await web3.eth.getAccounts();
        if (accounts.length > 0) {
            account = accounts[0];
            updateWalletInfo(account);
        }
    }
}

function updateWalletInfo(address) {
    const walletInfo = document.getElementById('walletInfo');
    if (walletInfo) {
        walletInfo.innerHTML = `
            <p>Connected Wallet: <strong>${formatAddress(address)}</strong></p>
            <p>Full Address: <span style="font-size: 0.9rem;">${address}</span></p>
            <button onclick="disconnectWallet()" class="btn-secondary">Disconnect</button>
        `;
    }
}

function disconnectWallet() {
    account = null;
    location.reload();
}
