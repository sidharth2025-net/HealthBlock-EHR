# 🏥 Secure Electronic Health Records (EHR) System

A blockchain-powered EHR system using **Hardhat** (local Ethereum) + **IPFS** for GitHub Codespaces.

## ✅ What's Different from Original

| Original | This Version |
|----------|-------------|
| MetaMask required | Works with OR without MetaMask |
| web3.storage (external) | Local IPFS or demo fallback |
| web3.js | ethers.js v6 |
| External Ganache | Built-in Hardhat local node |
| Manual setup | One-command Codespaces setup |

---

## 🚀 Quick Start in GitHub Codespaces

### Step 1: Open in Codespaces
Click **Code → Codespaces → Create codespace on main** in your GitHub repo.

The `.devcontainer/setup.sh` will auto-install all dependencies.

### Step 2: Start the Blockchain
Open a terminal and run:
```bash
cd backend
npm install
npx hardhat node --port 8545
```
**Keep this terminal open.** You'll see 20 test accounts with private keys printed.

### Step 3: Deploy Smart Contracts
Open a **new terminal**:
```bash
cd backend
npx hardhat run scripts/deploy.js --network localhost
```
This deploys all 4 contracts and saves addresses to `frontend/src/deployedAddresses.json`.

### Step 4: Start Frontend
Open a **third terminal**:
```bash
cd frontend
npm install
npm start
```
The React app opens on port 3000.

---

## 🌐 Using with MetaMask (Optional)

If you have MetaMask:
1. Add network: **Localhost 8545**, Chain ID **1337**
2. Import a private key from the Hardhat node output
3. The app auto-detects MetaMask and uses it

**Without MetaMask:** The app uses the first Hardhat test account automatically.

---

## 📁 Project Structure

```
ehr-codespaces/
├── .devcontainer/
│   ├── devcontainer.json    # Codespaces config
│   ├── setup.sh             # Install dependencies
│   └── start.sh             # Start all services
├── backend/
│   ├── contracts/
│   │   ├── PatientRegistration.sol
│   │   ├── DoctorRegistration.sol
│   │   ├── DiagnosticRegistration.sol
│   │   └── EHRContract.sol
│   ├── scripts/
│   │   └── deploy.js        # Deploy all contracts
│   └── hardhat.config.js
└── frontend/
    ├── src/
    │   ├── components/      # All React components
    │   ├── abis/            # Contract ABIs
    │   ├── Web3Context.js   # Blockchain connection
    │   ├── ipfsUtils.js     # IPFS upload/download
    │   └── deployedAddresses.json  # Auto-generated after deploy
    └── package.json
```

---

## 🏗️ Smart Contracts

| Contract | Purpose |
|----------|---------|
| `PatientRegistration` | Register/login patients |
| `DoctorRegistration` | Register/login doctors |
| `DiagnosticRegistration` | Register/login diagnostic centers |
| `EHRContract` | Create/view records + access control |

---

## 🔬 IPFS File Storage

Files are stored in this priority order:
1. **Local IPFS node** (if running on port 5001)
2. **web3.storage** (if `REACT_APP_WEB3_STORAGE_TOKEN` set)
3. **Demo local storage** (base64 in browser, for testing)

To run local IPFS:
```bash
# Install IPFS
wget https://dist.ipfs.tech/kubo/v0.24.0/kubo_v0.24.0_linux-amd64.tar.gz
tar xvf kubo_v0.24.0_linux-amd64.tar.gz
sudo ./kubo/install.sh

# Start IPFS
ipfs init
ipfs daemon
```

---

## 👥 User Roles & Flow

### Patient
1. Register → `patient_registration`
2. Login → `patient_login`
3. Dashboard: View records, Grant/Revoke doctor access

### Doctor  
1. Register → `doctor_registration`
2. Login → `doctor_login`
3. Dashboard: Create EHR records, View patient records (with permission)

### Diagnostic Center
1. Register → `diagnostic_registration`
2. Login → `diagnostic_login`
3. Dashboard: Create EHR records with IPFS file attachments

---

## 🧪 Test Data

Use these HH Numbers for testing:
- Patient: `PAT001`, `PAT002`
- Doctor: `DOC001`, `DOC002`
- Diagnostic: `DIAG001`

---

## 🛠️ Troubleshooting

**"No accounts found"** → Make sure Hardhat node is running (`npx hardhat node`)

**"Contract not deployed"** → Run `npx hardhat run scripts/deploy.js --network localhost`

**Addresses wrong** → Restart Hardhat and re-deploy (addresses change on restart)

**Port 8545 in use** → `pkill -f hardhat` then restart

---

## 📚 Tech Stack

- **Blockchain**: Hardhat + Solidity 0.8.20
- **Frontend**: React 18 + ethers.js v6
- **Storage**: IPFS (local/web3.storage/demo)
- **Hosting**: GitHub Codespaces (ports 3000, 8545, 5001)
