#!/bin/bash
set -e
echo "=== Setting up Secure EHR Project ==="

# Install backend dependencies
echo ">> Installing backend (Hardhat) dependencies..."
cd /workspaces/ehr-codespaces/backend
npm install

# Install frontend dependencies
echo ">> Installing frontend dependencies..."
cd /workspaces/ehr-codespaces/frontend
npm install

echo "=== Setup complete! ==="
echo "Run: bash .devcontainer/start.sh to start all services"
