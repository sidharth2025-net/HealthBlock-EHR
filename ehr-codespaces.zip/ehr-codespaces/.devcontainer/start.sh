#!/bin/bash
echo "=== Starting Secure EHR Services ==="

WORKDIR=/workspaces/ehr-codespaces

# Start Hardhat node in background
echo ">> Starting Hardhat local blockchain on port 8545..."
cd "$WORKDIR/backend"
npx hardhat node --port 8545 > /tmp/hardhat.log 2>&1 &
HARDHAT_PID=$!
echo "   Hardhat PID: $HARDHAT_PID"

# Wait for hardhat to be ready
echo ">> Waiting for blockchain to start..."
sleep 5

# Deploy contracts
echo ">> Deploying smart contracts..."
cd "$WORKDIR/backend"
npx hardhat run scripts/deploy.js --network localhost 2>&1 | tee /tmp/deploy.log

# Copy deployed addresses to frontend
echo ">> Copying deployed contract addresses to frontend..."
cp "$WORKDIR/backend/deployedAddresses.json" "$WORKDIR/frontend/src/deployedAddresses.json" 2>/dev/null || echo "Warning: deployedAddresses.json not found"

# Start frontend
echo ">> Starting React frontend on port 3000..."
cd "$WORKDIR/frontend"
npm start &

echo ""
echo "=== All services started ==="
echo "  Frontend: http://localhost:3000"
echo "  Blockchain RPC: http://localhost:8545"
echo ""
echo "Test accounts (pre-funded with 10000 ETH each):"
cat /tmp/hardhat.log | grep "Account #" | head -5
echo ""
echo "Use MetaMask with:"
echo "  Network: Localhost 8545"
echo "  Chain ID: 1337"
echo "  Import private key from hardhat output above"
