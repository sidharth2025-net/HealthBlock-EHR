import React, { useState, useEffect } from "react";
import { useParams, useNavigate, Link } from "react-router-dom";
import { useWeb3 } from "../Web3Context";

const DoctorDashboard = () => {
  const { hhNumber } = useParams();
  const { contracts, loading: web3Loading } = useWeb3();
  const navigate = useNavigate();
  const [doctor, setDoctor] = useState(null);
  const [loading, setLoading] = useState(true);
  const [patientHH, setPatientHH] = useState("");
  const [patientRecords, setPatientRecords] = useState(null);
  const [hasAccessResult, setHasAccessResult] = useState(null);
  const [status, setStatus] = useState("");

  useEffect(() => {
    if (!sessionStorage.getItem("loggedIn")) navigate("/doctor_login");
  }, [navigate]);

  useEffect(() => {
    const load = async () => {
      if (web3Loading || !contracts.doctorRegistration) return;
      try {
        const d = await contracts.doctorRegistration.getDoctorDetails(hhNumber);
        setDoctor({ address: d[0], name: d[1], specialization: d[2], hospitalName: d[3], email: d[4] });
      } catch (e) { console.error(e); }
      finally { setLoading(false); }
    };
    load();
  }, [web3Loading, contracts, hhNumber]);

  const checkPatient = async (e) => {
    e.preventDefault();
    setStatus("Checking access...");
    setPatientRecords(null);
    setHasAccessResult(null);
    try {
      const access = await contracts.ehrContract.hasAccess(patientHH, hhNumber);
      setHasAccessResult(access);
      if (access) {
        const records = await contracts.ehrContract.getRecords(patientHH);
        setPatientRecords(records);
        setStatus(`✅ Access granted. Found ${records.length} records.`);
      } else {
        setStatus("⛔ You do not have access to this patient's records. Ask the patient to grant access.");
      }
    } catch (err) {
      setStatus("❌ Error: " + (err.reason || err.message));
    }
  };

  const logout = () => { sessionStorage.clear(); navigate("/"); };

  if (loading || web3Loading) return <div className="loading"><div className="spinner"></div><p>Loading...</p></div>;

  return (
    <div>
      <div className="navbar" style={{ background: "linear-gradient(135deg, #2e7d32, #388e3c)" }}>
        <span className="navbar-brand">🏥 EHR System</span>
        <div className="navbar-links">
          <span style={{ marginRight: "10px" }}>🩺 {doctor?.name || hhNumber}</span>
          <button onClick={logout} className="btn btn-secondary" style={{ padding: "6px 14px", fontSize: "0.85rem" }}>Logout</button>
        </div>
      </div>

      <div className="container">
        {/* Profile */}
        {doctor && (
          <div className="card" style={{ marginTop: "20px", borderTop: "4px solid #2e7d32" }}>
            <h2 style={{ color: "#2e7d32", marginBottom: "15px" }}>🩺 Doctor Profile</h2>
            <div className="grid-2">
              <div><strong>Name:</strong> {doctor.name}</div>
              <div><strong>Specialization:</strong> {doctor.specialization}</div>
              <div><strong>Hospital:</strong> {doctor.hospitalName}</div>
              <div><strong>Email:</strong> {doctor.email}</div>
              <div><strong>HH Number:</strong> {hhNumber}</div>
              <div><strong>Wallet:</strong> <code style={{ fontSize: "0.8rem" }}>{doctor.address}</code></div>
            </div>
          </div>
        )}

        {/* Quick Actions */}
        <div className="dashboard-grid">
          <Link to={`/doctor/${hhNumber}/create-ehr`} className="dashboard-card">
            <div className="icon">✏️</div>
            <h3>Create EHR Record</h3>
          </Link>
          <div className="dashboard-card" style={{ cursor: "default", borderTopColor: "#2e7d32" }}>
            <div className="icon">📋</div>
            <h3>View Patient Records</h3>
            <p style={{ fontSize: "0.8rem", color: "#666" }}>Search by patient HH below</p>
          </div>
        </div>

        {/* View Patient Records */}
        <div className="card">
          <h2 style={{ color: "#2e7d32", marginBottom: "15px" }}>🔍 View Patient Records</h2>
          <p style={{ color: "#666", marginBottom: "15px", fontSize: "0.9rem" }}>
            Enter a patient's HH Number to view their records (requires patient's permission).
          </p>
          {status && <div className={`alert alert-${hasAccessResult === false ? "error" : "info"}`}>{status}</div>}
          <form onSubmit={checkPatient} style={{ display: "flex", gap: "10px", alignItems: "flex-end" }}>
            <div className="form-group" style={{ flex: 1, marginBottom: 0 }}>
              <label>Patient HH Number</label>
              <input value={patientHH} onChange={e => setPatientHH(e.target.value)} required placeholder="e.g. PAT001" />
            </div>
            <button type="submit" className="btn btn-success">Search Records</button>
          </form>

          {patientRecords && patientRecords.length > 0 && (
            <div style={{ marginTop: "20px" }}>
              <h3 style={{ marginBottom: "15px" }}>Records for Patient: {patientHH}</h3>
              {patientRecords.map((r, i) => (
                <div key={i} className="record-card" style={{ borderLeftColor: "#2e7d32" }}>
                  <h3>Record #{r.recordId || i + 1}</h3>
                  <div className="meta">{new Date(Number(r.timestamp) * 1000).toLocaleDateString()}</div>
                  <div className="detail"><span>Patient:</span> {r.patientName} | <span>Gender:</span> {r.gender} | <span>Blood Group:</span> {r.bloodGroup}</div>
                  <div className="detail"><span>Diagnosis:</span> {r.diagnosis}</div>
                  <div className="detail"><span>Prescription:</span> {r.prescription}</div>
                  {r.ipfsCid && <div className="detail"><span>IPFS CID:</span> <code style={{ fontSize: "0.8rem" }}>{r.ipfsCid}</code></div>}
                </div>
              ))}
            </div>
          )}
          {patientRecords && patientRecords.length === 0 && hasAccessResult && (
            <div className="alert alert-info" style={{ marginTop: "15px" }}>No records found for this patient.</div>
          )}
        </div>
      </div>
      <div className="footer"><p>Secure EHR System | Doctor Portal</p></div>
    </div>
  );
};

export default DoctorDashboard;
