import React, { useState, useEffect } from "react";
import { useParams, useNavigate, Link } from "react-router-dom";
import { useWeb3 } from "../Web3Context";

const PatientDashboard = () => {
  const { hhNumber } = useParams();
  const { contracts, loading: web3Loading } = useWeb3();
  const navigate = useNavigate();
  const [patient, setPatient] = useState(null);
  const [records, setRecords] = useState([]);
  const [grantForm, setGrantForm] = useState({ doctorHH: "", action: "grant" });
  const [status, setStatus] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!sessionStorage.getItem("loggedIn")) navigate("/patient_login");
  }, [navigate]);

  useEffect(() => {
    const load = async () => {
      if (web3Loading || !contracts.patientRegistration) return;
      try {
        const details = await contracts.patientRegistration.getPatientDetails(hhNumber);
        setPatient({
          address: details[0], name: details[1], dob: details[2],
          gender: details[3], bloodGroup: details[4], homeAddress: details[5], email: details[6]
        });
        const recs = await contracts.ehrContract.getRecords(hhNumber);
        setRecords(recs);
      } catch (e) {
        console.error(e);
      } finally {
        setLoading(false);
      }
    };
    load();
  }, [web3Loading, contracts, hhNumber]);

  const handleAccess = async (e) => {
    e.preventDefault();
    setStatus("Processing...");
    try {
      let tx;
      if (grantForm.action === "grant") {
        tx = await contracts.ehrContract.grantAccess(hhNumber, grantForm.doctorHH);
      } else {
        tx = await contracts.ehrContract.revokeAccess(hhNumber, grantForm.doctorHH);
      }
      await tx.wait();
      setStatus(`✅ Access ${grantForm.action === "grant" ? "granted" : "revoked"} for doctor ${grantForm.doctorHH}`);
    } catch (err) {
      setStatus("❌ Error: " + (err.reason || err.message));
    }
  };

  const logout = () => {
    sessionStorage.clear();
    navigate("/");
  };

  if (loading || web3Loading) return <div className="loading"><div className="spinner"></div><p>Loading dashboard...</p></div>;

  return (
    <div>
      <div className="navbar">
        <span className="navbar-brand">🏥 EHR System</span>
        <div className="navbar-links">
          <span style={{ marginRight: "10px" }}>👤 {patient?.name || hhNumber}</span>
          <button onClick={logout} className="btn btn-secondary" style={{ padding: "6px 14px", fontSize: "0.85rem" }}>Logout</button>
        </div>
      </div>

      <div className="container">
        {/* Profile Card */}
        {patient && (
          <div className="card" style={{ marginTop: "20px", borderTop: "4px solid #1a237e" }}>
            <h2 style={{ color: "#1a237e", marginBottom: "15px" }}>👤 Patient Profile</h2>
            <div className="grid-2">
              <div><strong>Name:</strong> {patient.name}</div>
              <div><strong>Date of Birth:</strong> {patient.dob}</div>
              <div><strong>Gender:</strong> {patient.gender}</div>
              <div><strong>Blood Group:</strong> {patient.bloodGroup}</div>
              <div><strong>Email:</strong> {patient.email}</div>
              <div><strong>HH Number:</strong> {hhNumber}</div>
              <div style={{ gridColumn: "1/-1" }}><strong>Address:</strong> {patient.homeAddress}</div>
              <div style={{ gridColumn: "1/-1" }}><strong>Wallet:</strong> <code style={{ fontSize: "0.8rem" }}>{patient.address}</code></div>
            </div>
          </div>
        )}

        {/* Quick Stats */}
        <div className="dashboard-grid">
          <div className="dashboard-card">
            <div className="icon">📋</div>
            <h3>Total Records</h3>
            <div style={{ fontSize: "2rem", fontWeight: "bold", color: "#1a237e" }}>{records.length}</div>
          </div>
          <Link to={`/patient/${hhNumber}/viewrecords`} className="dashboard-card">
            <div className="icon">🔍</div>
            <h3>View All Records</h3>
          </Link>
          <div className="dashboard-card" style={{ cursor: "default", borderTopColor: "#2e7d32" }}>
            <div className="icon">🔐</div>
            <h3>Access Control</h3>
            <p style={{ fontSize: "0.8rem", color: "#666" }}>Grant/Revoke doctor access below</p>
          </div>
        </div>

        {/* Access Control */}
        <div className="card">
          <h2 style={{ color: "#1a237e", marginBottom: "15px" }}>🔑 Doctor Access Control</h2>
          <p style={{ color: "#666", marginBottom: "20px", fontSize: "0.9rem" }}>
            Grant or revoke a doctor's ability to view your records.
          </p>
          {status && <div className="alert alert-info">{status}</div>}
          <form onSubmit={handleAccess} style={{ display: "flex", gap: "10px", flexWrap: "wrap", alignItems: "flex-end" }}>
            <div className="form-group" style={{ flex: 1, minWidth: "200px", marginBottom: 0 }}>
              <label>Doctor HH Number</label>
              <input value={grantForm.doctorHH}
                onChange={e => setGrantForm({ ...grantForm, doctorHH: e.target.value })}
                required placeholder="e.g. DOC001" />
            </div>
            <div className="form-group" style={{ marginBottom: 0 }}>
              <label>Action</label>
              <select value={grantForm.action} onChange={e => setGrantForm({ ...grantForm, action: e.target.value })}>
                <option value="grant">Grant Access</option>
                <option value="revoke">Revoke Access</option>
              </select>
            </div>
            <button type="submit" className={grantForm.action === "grant" ? "btn btn-success" : "btn btn-danger"}>
              {grantForm.action === "grant" ? "✅ Grant" : "❌ Revoke"}
            </button>
          </form>
        </div>

        {/* Recent Records */}
        <div className="card">
          <h2 style={{ color: "#1a237e", marginBottom: "15px" }}>📋 Recent Health Records</h2>
          {records.length === 0 ? (
            <div className="alert alert-info">No health records yet. Ask your doctor to create one.</div>
          ) : (
            records.slice(-3).reverse().map((r, i) => (
              <div key={i} className="record-card">
                <h3>Record #{r.recordId || i + 1}</h3>
                <div className="meta">
                  {new Date(Number(r.timestamp) * 1000).toLocaleDateString()} | Dr. {r.doctorName}
                </div>
                <div className="detail"><span>Diagnosis:</span> {r.diagnosis}</div>
                <div className="detail"><span>Prescription:</span> {r.prescription}</div>
                {r.ipfsCid && r.ipfsCid !== "" && (
                  <div style={{ marginTop: "8px" }}>
                    <span style={{ fontSize: "0.8rem", color: "#666" }}>📁 IPFS: {r.ipfsCid.slice(0, 30)}...</span>
                  </div>
                )}
              </div>
            ))
          )}
          {records.length > 3 && (
            <Link to={`/patient/${hhNumber}/viewrecords`} className="btn btn-primary" style={{ marginTop: "10px" }}>
              View All {records.length} Records →
            </Link>
          )}
        </div>
      </div>
      <div className="footer"><p>Secure EHR System | Powered by Ethereum + IPFS</p></div>
    </div>
  );
};

export default PatientDashboard;
