import React, { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { useWeb3 } from "../Web3Context";
import { uploadToIPFS } from "../ipfsUtils";

const DiagnosticDashboard = () => {
  const { hhNumber } = useParams();
  const { contracts, loading: web3Loading, account } = useWeb3();
  const navigate = useNavigate();
  const [diagnostic, setDiagnostic] = useState(null);
  const [loading, setLoading] = useState(true);
  const [status, setStatus] = useState({ type: "", msg: "" });
  const [uploadLoading, setUploadLoading] = useState(false);

  const [form, setForm] = useState({
    patientHH: "", patientName: "", doctorName: "", doctorHH: "",
    age: "", gender: "", bloodGroup: "", diagnosis: "", prescription: ""
  });
  const [file, setFile] = useState(null);

  useEffect(() => {
    if (!sessionStorage.getItem("loggedIn")) navigate("/diagnostic_login");
  }, [navigate]);

  useEffect(() => {
    const load = async () => {
      if (web3Loading || !contracts.diagnosticRegistration) return;
      try {
        const d = await contracts.diagnosticRegistration.getDiagnosticDetails(hhNumber);
        setDiagnostic({ address: d[0], diagnosticName: d[1], hospitalName: d[2], location: d[3], email: d[4] });
      } catch (e) { console.error(e); }
      finally { setLoading(false); }
    };
    load();
  }, [web3Loading, contracts, hhNumber]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setUploadLoading(true);
    setStatus({ type: "", msg: "" });

    try {
      let cid = "";

      // Upload file to IPFS if provided
      if (file) {
        setStatus({ type: "info", msg: "📤 Uploading file to IPFS..." });
        const result = await uploadToIPFS(file);
        cid = result.cid;
        setStatus({ type: "info", msg: `✅ File uploaded to IPFS (${result.source}). CID: ${cid.slice(0, 20)}...` });
      }

      setStatus({ type: "info", msg: "⛓️ Writing EHR to blockchain..." });

      const recordId = `REC_${Date.now()}`;
      const tx = await contracts.ehrContract.createRecord(
        recordId,
        form.patientHH,
        form.doctorHH,
        form.patientName,
        form.doctorName,
        form.age,
        form.gender,
        form.bloodGroup,
        form.diagnosis,
        form.prescription,
        cid
      );
      await tx.wait();

      setStatus({ type: "success", msg: `✅ EHR record created successfully on blockchain! Record ID: ${recordId}` });
      setForm({
        patientHH: "", patientName: "", doctorName: "", doctorHH: "",
        age: "", gender: "", bloodGroup: "", diagnosis: "", prescription: ""
      });
      setFile(null);
    } catch (err) {
      setStatus({ type: "error", msg: "❌ Error: " + (err.reason || err.message) });
    } finally {
      setUploadLoading(false);
    }
  };

  const logout = () => { sessionStorage.clear(); navigate("/"); };

  if (loading || web3Loading) return <div className="loading"><div className="spinner"></div><p>Loading...</p></div>;

  return (
    <div>
      <div className="navbar" style={{ background: "linear-gradient(135deg, #6a1b9a, #7b1fa2)" }}>
        <span className="navbar-brand">🏥 EHR System</span>
        <div className="navbar-links">
          <span style={{ marginRight: "10px" }}>🔬 {diagnostic?.diagnosticName || hhNumber}</span>
          <button onClick={logout} className="btn btn-secondary" style={{ padding: "6px 14px", fontSize: "0.85rem" }}>Logout</button>
        </div>
      </div>

      <div className="container">
        {diagnostic && (
          <div className="card" style={{ marginTop: "20px", borderTop: "4px solid #6a1b9a" }}>
            <h2 style={{ color: "#6a1b9a", marginBottom: "15px" }}>🔬 Diagnostic Center Profile</h2>
            <div className="grid-2">
              <div><strong>Center Name:</strong> {diagnostic.diagnosticName}</div>
              <div><strong>Hospital:</strong> {diagnostic.hospitalName}</div>
              <div><strong>Location:</strong> {diagnostic.location}</div>
              <div><strong>Email:</strong> {diagnostic.email}</div>
              <div><strong>HH Number:</strong> {hhNumber}</div>
            </div>
          </div>
        )}

        {/* Create EHR Form */}
        <div className="card" style={{ marginTop: "20px" }}>
          <h2 style={{ color: "#6a1b9a", marginBottom: "20px" }}>📋 Create Electronic Health Record</h2>

          {status.msg && (
            <div className={`alert alert-${status.type}`}>{status.msg}</div>
          )}

          <form onSubmit={handleSubmit}>
            <h3 style={{ color: "#555", marginBottom: "15px", fontSize: "1rem" }}>Patient Information</h3>
            <div className="grid-2">
              <div className="form-group">
                <label>Patient HH Number *</label>
                <input name="patientHH" value={form.patientHH} onChange={e => setForm({ ...form, patientHH: e.target.value })} required placeholder="e.g. PAT001" />
              </div>
              <div className="form-group">
                <label>Patient Name *</label>
                <input name="patientName" value={form.patientName} onChange={e => setForm({ ...form, patientName: e.target.value })} required />
              </div>
              <div className="form-group">
                <label>Age *</label>
                <input name="age" type="number" value={form.age} onChange={e => setForm({ ...form, age: e.target.value })} required placeholder="25" />
              </div>
              <div className="form-group">
                <label>Gender *</label>
                <select name="gender" value={form.gender} onChange={e => setForm({ ...form, gender: e.target.value })} required>
                  <option value="">Select</option>
                  <option>Male</option><option>Female</option><option>Other</option>
                </select>
              </div>
              <div className="form-group">
                <label>Blood Group *</label>
                <select name="bloodGroup" value={form.bloodGroup} onChange={e => setForm({ ...form, bloodGroup: e.target.value })} required>
                  <option value="">Select</option>
                  {["A+", "A-", "B+", "B-", "O+", "O-", "AB+", "AB-"].map(b => <option key={b}>{b}</option>)}
                </select>
              </div>
            </div>

            <h3 style={{ color: "#555", margin: "15px 0", fontSize: "1rem" }}>Medical Information</h3>
            <div className="grid-2">
              <div className="form-group">
                <label>Doctor HH Number</label>
                <input name="doctorHH" value={form.doctorHH} onChange={e => setForm({ ...form, doctorHH: e.target.value })} placeholder="e.g. DOC001" />
              </div>
              <div className="form-group">
                <label>Doctor Name</label>
                <input name="doctorName" value={form.doctorName} onChange={e => setForm({ ...form, doctorName: e.target.value })} />
              </div>
            </div>
            <div className="form-group">
              <label>Diagnosis *</label>
              <textarea name="diagnosis" value={form.diagnosis} onChange={e => setForm({ ...form, diagnosis: e.target.value })} required rows={3} />
            </div>
            <div className="form-group">
              <label>Prescription / Notes *</label>
              <textarea name="prescription" value={form.prescription} onChange={e => setForm({ ...form, prescription: e.target.value })} required rows={3} />
            </div>

            <div className="form-group">
              <label>📁 Attach Medical File (PDF/Image) — uploads to IPFS</label>
              <input type="file" accept=".pdf,.jpg,.jpeg,.png,.dicom"
                onChange={e => setFile(e.target.files[0])}
                style={{ border: "2px dashed #ccc", padding: "15px", borderRadius: "8px", cursor: "pointer" }} />
              {file && <p style={{ color: "#2e7d32", marginTop: "5px", fontSize: "0.85rem" }}>Selected: {file.name} ({(file.size / 1024).toFixed(1)} KB)</p>}
            </div>

            <button type="submit" className="btn" disabled={uploadLoading}
              style={{ width: "100%", padding: "14px", background: "#6a1b9a", color: "white", fontSize: "1rem" }}>
              {uploadLoading ? "⏳ Processing..." : "✅ Create EHR Record on Blockchain"}
            </button>
          </form>
        </div>
      </div>
      <div className="footer"><p>Secure EHR System | Diagnostic Portal</p></div>
    </div>
  );
};

export default DiagnosticDashboard;
