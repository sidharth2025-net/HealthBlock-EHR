import React, { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import { useWeb3 } from "../Web3Context";

const DoctorLogin = () => {
  const { contracts, loading: web3Loading } = useWeb3();
  const navigate = useNavigate();
  const [form, setForm] = useState({ hhNumber: "", password: "" });
  const [status, setStatus] = useState({ type: "", msg: "" });
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setStatus({ type: "", msg: "" });
    try {
      const exists = await contracts.doctorRegistration.isRegisteredDoctor(form.hhNumber);
      if (!exists) {
        setStatus({ type: "error", msg: "Doctor not found. Please register first." });
        setLoading(false);
        return;
      }
      const valid = await contracts.doctorRegistration.validatePassword(form.hhNumber, form.password);
      if (!valid) {
        setStatus({ type: "error", msg: "Invalid password." });
        setLoading(false);
        return;
      }
      sessionStorage.setItem("loggedIn", "doctor");
      sessionStorage.setItem("hhNumber", form.hhNumber);
      navigate(`/doctor/${form.hhNumber}`);
    } catch (err) {
      setStatus({ type: "error", msg: "Login error: " + (err.reason || err.message) });
    } finally {
      setLoading(false);
    }
  };

  if (web3Loading) return <div className="loading"><div className="spinner"></div><p>Connecting...</p></div>;

  return (
    <div>
      <div className="page-header" style={{ background: "linear-gradient(135deg, #2e7d32, #388e3c)" }}>
        <h1>🩺 Doctor Login</h1>
      </div>
      <div className="container" style={{ maxWidth: "420px" }}>
        <div className="card">
          {status.msg && (
            <div className={`alert alert-${status.type === "success" ? "success" : "error"}`}>{status.msg}</div>
          )}
          <form onSubmit={handleSubmit}>
            <div className="form-group">
              <label>Doctor HH Number</label>
              <input value={form.hhNumber} onChange={e => setForm({ ...form, hhNumber: e.target.value })} required placeholder="e.g. DOC001" />
            </div>
            <div className="form-group">
              <label>Password</label>
              <input type="password" value={form.password} onChange={e => setForm({ ...form, password: e.target.value })} required />
            </div>
            <button type="submit" className="btn btn-success" disabled={loading} style={{ width: "100%", padding: "13px" }}>
              {loading ? "Logging in..." : "Login as Doctor"}
            </button>
          </form>
          <p style={{ textAlign: "center", marginTop: "15px", color: "#666", fontSize: "0.9rem" }}>
            No account? <Link to="/doctor_registration" style={{ color: "#2e7d32" }}>Register here</Link>
          </p>
          <p style={{ textAlign: "center", marginTop: "8px" }}>
            <Link to="/" style={{ color: "#999", fontSize: "0.85rem" }}>← Back to Home</Link>
          </p>
        </div>
      </div>
    </div>
  );
};

export default DoctorLogin;
