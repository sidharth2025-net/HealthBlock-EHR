import React from "react";
import { Link } from "react-router-dom";

const LandingPage = () => {
  return (
    <div>
      {/* Hero */}
      <div style={{
        background: "linear-gradient(135deg, #1a237e 0%, #283593 50%, #1565c0 100%)",
        color: "white",
        padding: "80px 30px",
        textAlign: "center",
        minHeight: "60vh",
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center"
      }}>
        <div style={{ fontSize: "4rem", marginBottom: "20px" }}>🏥</div>
        <h1 style={{ fontSize: "2.8rem", marginBottom: "15px", fontWeight: 800 }}>
          Secure Electronic Health Records
        </h1>
        <p style={{ fontSize: "1.2rem", opacity: 0.9, maxWidth: "600px", marginBottom: "40px", lineHeight: 1.6 }}>
          A blockchain-powered EHR system with IPFS storage for secure, 
          tamper-proof patient records.
        </p>
        <div style={{ display: "flex", gap: "15px", flexWrap: "wrap", justifyContent: "center" }}>
          <Link to="/register" style={{
            background: "white",
            color: "#1a237e",
            padding: "14px 32px",
            borderRadius: "8px",
            textDecoration: "none",
            fontWeight: 700,
            fontSize: "1rem"
          }}>
            Get Started →
          </Link>
          <Link to="/patient_login" style={{
            background: "rgba(255,255,255,0.15)",
            color: "white",
            padding: "14px 32px",
            borderRadius: "8px",
            textDecoration: "none",
            fontWeight: 700,
            fontSize: "1rem",
            border: "2px solid rgba(255,255,255,0.4)"
          }}>
            Login
          </Link>
        </div>
      </div>

      {/* Features */}
      <div className="container" style={{ padding: "60px 20px" }}>
        <h2 style={{ textAlign: "center", marginBottom: "40px", color: "#1a237e" }}>
          System Features
        </h2>
        <div className="grid-3">
          {[
            { icon: "🔒", title: "Blockchain Security", desc: "All records stored on Ethereum smart contracts. Tamper-proof and transparent." },
            { icon: "📁", title: "IPFS File Storage", desc: "Medical files uploaded to IPFS. Decentralized, permanent, and content-addressed." },
            { icon: "🩺", title: "Multi-Role Access", desc: "Patients, Doctors, and Diagnostics each have dedicated dashboards and permissions." },
            { icon: "🔑", title: "Access Control", desc: "Patients control who can view their records. Grant or revoke doctor access anytime." },
            { icon: "📋", title: "Complete EHR", desc: "Full electronic health records with diagnosis, prescriptions, and file attachments." },
            { icon: "🌐", title: "Codespaces Ready", desc: "Runs fully in GitHub Codespaces with pre-configured Hardhat blockchain." },
          ].map((f, i) => (
            <div key={i} className="card" style={{ textAlign: "center" }}>
              <div style={{ fontSize: "2.5rem", marginBottom: "15px" }}>{f.icon}</div>
              <h3 style={{ color: "#1a237e", marginBottom: "10px" }}>{f.title}</h3>
              <p style={{ color: "#666", lineHeight: 1.6, fontSize: "0.92rem" }}>{f.desc}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Login links */}
      <div style={{ background: "#1a237e", color: "white", padding: "50px 20px", textAlign: "center" }}>
        <h2 style={{ marginBottom: "30px" }}>Access Your Portal</h2>
        <div style={{ display: "flex", gap: "20px", justifyContent: "center", flexWrap: "wrap" }}>
          {[
            { label: "👤 Patient Portal", to: "/patient_login" },
            { label: "🩺 Doctor Portal", to: "/doctor_login" },
            { label: "🔬 Diagnostic Portal", to: "/diagnostic_login" },
          ].map((p) => (
            <Link key={p.to} to={p.to} style={{
              background: "rgba(255,255,255,0.15)",
              color: "white",
              padding: "16px 28px",
              borderRadius: "10px",
              textDecoration: "none",
              fontWeight: 700,
              border: "2px solid rgba(255,255,255,0.3)",
              fontSize: "1rem"
            }}>
              {p.label}
            </Link>
          ))}
        </div>
      </div>

      {/* Footer */}
      <div className="footer">
        <p>© 2024 Secure EHR System | Built on Ethereum + IPFS | Hardhat Local Network</p>
      </div>
    </div>
  );
};

export default LandingPage;
