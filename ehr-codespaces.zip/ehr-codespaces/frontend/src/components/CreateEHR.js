import React, { useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { useWeb3 } from "../Web3Context";
import { uploadToIPFS } from "../ipfsUtils";

const CreateEHR = () => {
  const { hhNumber } = useParams(); // Doctor's HH
  const { contracts } = useWeb3();
  const navigate = useNavigate();
  const [form, setForm] = useState({
    patientHH: "", patientName: "", age: "", gender: "",
    bloodGroup: "", diagnosis: "", prescription: ""
  });
  const [file, setFile] = useState(null);
  const [status, setStatus] = useState({ type: "", msg: "" });
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setStatus({ type: "", msg: "" });
    try {
      // Check access
      const access = await contracts.ehrContract.hasAccess(form.patientHH, hhNumber);
      if (!access) {
        setStatus({ type: "error", msg: "⛔ You don't have access to this patient's records. Ask them to grant access first." });
        setLoading(false);
        return;
      }

      let cid = "";
      if (file) {
        setStatus({ type: "info", msg: "📤 Uploading file to IPFS..." });
        const result = await uploadToIPFS(file);
        cid = result.cid;
      }

      setStatus({ type: "info", msg: "⛓️ Writing to blockchain..." });

      // Get doctor details
      const doctorDetails = await contracts.doctorRegistration.getDoctorDetails(hhNumber);
      const doctorName = doctorDetails[1];

      const recordId = `REC_${Date.now()}`;
      const tx = await contracts.ehrContract.createRecord(
        recordId, form.patientHH, hhNumber, form.patientName,
        doctorName, form.age, form.gender, form.bloodGroup,
        form.diagnosis, form.prescription, cid
      );
      await tx.wait();

      setStatus({ type: "success", msg: "✅ EHR record created successfully!" });
      setTimeout(() => navigate(`/doctor/${hhNumber}`), 2000);
    } catch (err) {
      setStatus({ type: "error", msg: "❌ " + (err.reason || err.message) });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div>
      <div className="page-header" style={{ background: "linear-gradient(135deg, #2e7d32, #388e3c)" }}>
        <h1>✏️ Create EHR Record</h1>
        <p>Create a new Electronic Health Record for a patient</p>
      </div>
      <div className="container" style={{ maxWidth: "700px" }}>
        <div className="card">
          {status.msg && <div className={`alert alert-${status.type}`}>{status.msg}</div>}
          <form onSubmit={handleSubmit}>
            <div className="grid-2">
              <div className="form-group">
                <label>Patient HH Number *</label>
                <input value={form.patientHH} onChange={e => setForm({ ...form, patientHH: e.target.value })} required placeholder="e.g. PAT001" />
              </div>
              <div className="form-group">
                <label>Patient Name *</label>
                <input value={form.patientName} onChange={e => setForm({ ...form, patientName: e.target.value })} required />
              </div>
              <div className="form-group">
                <label>Age *</label>
                <input type="number" value={form.age} onChange={e => setForm({ ...form, age: e.target.value })} required />
              </div>
              <div className="form-group">
                <label>Gender *</label>
                <select value={form.gender} onChange={e => setForm({ ...form, gender: e.target.value })} required>
                  <option value="">Select</option>
                  <option>Male</option><option>Female</option><option>Other</option>
                </select>
              </div>
              <div className="form-group">
                <label>Blood Group *</label>
                <select value={form.bloodGroup} onChange={e => setForm({ ...form, bloodGroup: e.target.value })} required>
                  <option value="">Select</option>
                  {["A+","A-","B+","B-","O+","O-","AB+","AB-"].map(b => <option key={b}>{b}</option>)}
                </select>
              </div>
            </div>
            <div className="form-group">
              <label>Diagnosis *</label>
              <textarea value={form.diagnosis} onChange={e => setForm({ ...form, diagnosis: e.target.value })} required rows={3} />
            </div>
            <div className="form-group">
              <label>Prescription *</label>
              <textarea value={form.prescription} onChange={e => setForm({ ...form, prescription: e.target.value })} required rows={3} />
            </div>
            <div className="form-group">
              <label>Attach File (optional, uploads to IPFS)</label>
              <input type="file" onChange={e => setFile(e.target.files[0])}
                style={{ border: "2px dashed #ccc", padding: "10px", borderRadius: "8px" }} />
            </div>
            <div style={{ display: "flex", gap: "10px" }}>
              <button type="button" className="btn btn-secondary" onClick={() => navigate(`/doctor/${hhNumber}`)}>← Cancel</button>
              <button type="submit" className="btn btn-success" disabled={loading} style={{ flex: 1 }}>
                {loading ? "Creating..." : "✅ Create EHR Record"}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default CreateEHR;
