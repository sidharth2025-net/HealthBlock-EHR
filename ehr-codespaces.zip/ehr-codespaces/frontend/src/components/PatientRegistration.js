import React, { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import { useWeb3 } from "../Web3Context";

const PatientRegistration = () => {
  const { contracts, loading: web3Loading } = useWeb3();
  const navigate = useNavigate();

  const [form, setForm] = useState({
    name: "", dob: "", gender: "", bloodGroup: "",
    homeAddress: "", email: "", hhNumber: "", password: "", confirmPassword: ""
  });
  const [status, setStatus] = useState({ type: "", msg: "" });
  const [loading, setLoading] = useState(false);

  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const handleSubmit = async (e) => {
    e.preventDefault();
    setStatus({ type: "", msg: "" });

    if (form.password !== form.confirmPassword) {
      return setStatus({ type: "error", msg: "Passwords do not match!" });
    }
    if (!form.hhNumber.trim()) {
      return setStatus({ type: "error", msg: "HH Number is required!" });
    }

    setLoading(true);
    try {
      const contract = contracts.patientRegistration;

      // Check if already registered
      const exists = await contract.isRegisteredPatient(form.hhNumber);
      if (exists) {
        setStatus({ type: "error", msg: "Patient with this HH Number already registered!" });
        setLoading(false);
        return;
      }

      // Register on blockchain
      const tx = await contract.registerPatient(
        form.name, form.dob, form.gender, form.bloodGroup,
        form.homeAddress, form.email, form.hhNumber, form.password
      );
      await tx.wait();

      setStatus({ type: "success", msg: "✅ Registration successful! Redirecting to login..." });
      setTimeout(() => navigate("/patient_login"), 2000);
    } catch (err) {
      console.error(err);
      setStatus({ type: "error", msg: "Registration failed: " + (err.reason || err.message) });
    } finally {
      setLoading(false);
    }
  };

  if (web3Loading) {
    return <div className="loading"><div className="spinner"></div><p>Connecting to blockchain...</p></div>;
  }

  return (
    <div>
      <div className="page-header">
        <h1>👤 Patient Registration</h1>
        <p>Create your account on the blockchain</p>
      </div>
      <div className="container" style={{ maxWidth: "650px" }}>
        <div className="card">
          {status.msg && (
            <div className={`alert alert-${status.type === "success" ? "success" : "error"}`}>
              {status.msg}
            </div>
          )}
          <form onSubmit={handleSubmit}>
            <div className="grid-2">
              <div className="form-group">
                <label>Full Name *</label>
                <input name="name" value={form.name} onChange={handleChange} required placeholder="John Doe" />
              </div>
              <div className="form-group">
                <label>Date of Birth *</label>
                <input name="dob" type="date" value={form.dob} onChange={handleChange} required />
              </div>
              <div className="form-group">
                <label>Gender *</label>
                <select name="gender" value={form.gender} onChange={handleChange} required>
                  <option value="">Select Gender</option>
                  <option>Male</option>
                  <option>Female</option>
                  <option>Other</option>
                </select>
              </div>
              <div className="form-group">
                <label>Blood Group *</label>
                <select name="bloodGroup" value={form.bloodGroup} onChange={handleChange} required>
                  <option value="">Select Blood Group</option>
                  {["A+", "A-", "B+", "B-", "O+", "O-", "AB+", "AB-"].map(b => (
                    <option key={b}>{b}</option>
                  ))}
                </select>
              </div>
            </div>
            <div className="form-group">
              <label>Home Address *</label>
              <input name="homeAddress" value={form.homeAddress} onChange={handleChange} required placeholder="123 Main St, City" />
            </div>
            <div className="form-group">
              <label>Email *</label>
              <input name="email" type="email" value={form.email} onChange={handleChange} required placeholder="john@example.com" />
            </div>
            <div className="form-group">
              <label>HH Number (Unique ID) *</label>
              <input name="hhNumber" value={form.hhNumber} onChange={handleChange} required placeholder="e.g. PAT001" />
            </div>
            <div className="grid-2">
              <div className="form-group">
                <label>Password *</label>
                <input name="password" type="password" value={form.password} onChange={handleChange} required />
              </div>
              <div className="form-group">
                <label>Confirm Password *</label>
                <input name="confirmPassword" type="password" value={form.confirmPassword} onChange={handleChange} required />
              </div>
            </div>
            <button type="submit" className="btn btn-primary" disabled={loading} style={{ width: "100%", padding: "14px" }}>
              {loading ? "Registering on Blockchain..." : "Register Patient"}
            </button>
          </form>
          <p style={{ textAlign: "center", marginTop: "15px", color: "#666" }}>
            Already registered? <Link to="/patient_login" style={{ color: "#1a237e" }}>Login here</Link>
          </p>
        </div>
      </div>
    </div>
  );
};

export default PatientRegistration;
