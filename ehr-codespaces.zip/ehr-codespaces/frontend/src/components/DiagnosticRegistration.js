import React, { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import { useWeb3 } from "../Web3Context";

const DiagnosticRegistration = () => {
  const { contracts, loading: web3Loading } = useWeb3();
  const navigate = useNavigate();

  const [form, setForm] = useState({
    diagnosticName: "", hospitalName: "", diagnosticLocation: "",
    email: "", hhNumber: "", password: "", confirmPassword: ""
  });
  const [status, setStatus] = useState({ type: "", msg: "" });
  const [loading, setLoading] = useState(false);

  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (form.password !== form.confirmPassword) {
      return setStatus({ type: "error", msg: "Passwords do not match!" });
    }
    setLoading(true);
    try {
      const exists = await contracts.diagnosticRegistration.isRegisteredDiagnostic(form.hhNumber);
      if (exists) {
        setStatus({ type: "error", msg: "Diagnostic center with this HH Number already registered!" });
        setLoading(false);
        return;
      }
      const tx = await contracts.diagnosticRegistration.registerDiagnostic(
        form.diagnosticName, form.hospitalName, form.diagnosticLocation,
        form.email, form.hhNumber, form.password
      );
      await tx.wait();
      setStatus({ type: "success", msg: "✅ Diagnostic center registered! Redirecting..." });
      setTimeout(() => navigate("/diagnostic_login"), 2000);
    } catch (err) {
      setStatus({ type: "error", msg: "Registration failed: " + (err.reason || err.message) });
    } finally {
      setLoading(false);
    }
  };

  if (web3Loading) return <div className="loading"><div className="spinner"></div><p>Connecting...</p></div>;

  return (
    <div>
      <div className="page-header" style={{ background: "linear-gradient(135deg, #6a1b9a, #7b1fa2)" }}>
        <h1>🔬 Diagnostic Center Registration</h1>
        <p>Register your diagnostic center on the blockchain</p>
      </div>
      <div className="container" style={{ maxWidth: "600px" }}>
        <div className="card">
          {status.msg && (
            <div className={`alert alert-${status.type === "success" ? "success" : "error"}`}>{status.msg}</div>
          )}
          <form onSubmit={handleSubmit}>
            <div className="form-group">
              <label>Diagnostic Center Name *</label>
              <input name="diagnosticName" value={form.diagnosticName} onChange={handleChange} required placeholder="City Diagnostics Lab" />
            </div>
            <div className="form-group">
              <label>Hospital/Organization Name *</label>
              <input name="hospitalName" value={form.hospitalName} onChange={handleChange} required placeholder="City Medical Group" />
            </div>
            <div className="form-group">
              <label>Location *</label>
              <input name="diagnosticLocation" value={form.diagnosticLocation} onChange={handleChange} required placeholder="123 Health Ave, City" />
            </div>
            <div className="form-group">
              <label>Email *</label>
              <input name="email" type="email" value={form.email} onChange={handleChange} required />
            </div>
            <div className="form-group">
              <label>Diagnostic HH Number (Unique ID) *</label>
              <input name="hhNumber" value={form.hhNumber} onChange={handleChange} required placeholder="e.g. DIAG001" />
            </div>
            <div className="grid-2">
              <div className="form-group">
                <label>Password *</label>
                <input name="password" type="password" value={form.password} onChange={handleChange} required />
              </div>
              <div className="form-group">
                <label>Confirm Password *</label>
                <input name="confirmPassword" type="password" value={form.confirmPassword} onChange={handleChange} required />
              </div>
            </div>
            <button type="submit" className="btn" disabled={loading}
              style={{ width: "100%", padding: "14px", background: "#6a1b9a", color: "white" }}>
              {loading ? "Registering..." : "Register Diagnostic Center"}
            </button>
          </form>
          <p style={{ textAlign: "center", marginTop: "15px", color: "#666" }}>
            Already registered? <Link to="/diagnostic_login" style={{ color: "#6a1b9a" }}>Login here</Link>
          </p>
        </div>
      </div>
    </div>
  );
};

export default DiagnosticRegistration;
