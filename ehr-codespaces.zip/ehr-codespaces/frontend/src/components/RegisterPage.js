import React from "react";
import { Link } from "react-router-dom";

const RegisterPage = () => {
  return (
    <div>
      <div className="page-header">
        <h1>Create Account</h1>
        <p>Register as a Patient, Doctor, or Diagnostic Center</p>
      </div>
      <div className="container" style={{ maxWidth: "800px" }}>
        <div className="grid-3">
          {[
            {
              icon: "👤",
              title: "Patient",
              desc: "Register as a patient to manage your health records",
              to: "/patient_registration",
              color: "#1565c0"
            },
            {
              icon: "🩺",
              title: "Doctor",
              desc: "Register as a doctor to create and manage patient EHRs",
              to: "/doctor_registration",
              color: "#2e7d32"
            },
            {
              icon: "🔬",
              title: "Diagnostic Center",
              desc: "Register your diagnostic center to upload medical reports",
              to: "/diagnostic_registration",
              color: "#6a1b9a"
            },
          ].map((r) => (
            <Link key={r.to} to={r.to} style={{ textDecoration: "none" }}>
              <div className="card" style={{
                textAlign: "center",
                cursor: "pointer",
                borderTop: `4px solid ${r.color}`,
                transition: "transform 0.2s"
              }}
                onMouseOver={e => e.currentTarget.style.transform = "translateY(-4px)"}
                onMouseOut={e => e.currentTarget.style.transform = "translateY(0)"}
              >
                <div style={{ fontSize: "3rem", marginBottom: "15px" }}>{r.icon}</div>
                <h3 style={{ color: r.color, marginBottom: "10px" }}>{r.title}</h3>
                <p style={{ color: "#666", fontSize: "0.9rem", lineHeight: 1.5 }}>{r.desc}</p>
                <div style={{
                  marginTop: "20px",
                  background: r.color,
                  color: "white",
                  padding: "10px",
                  borderRadius: "6px",
                  fontWeight: 600
                }}>
                  Register as {r.title} →
                </div>
              </div>
            </Link>
          ))}
        </div>
        <p style={{ textAlign: "center", marginTop: "20px", color: "#666" }}>
          Already have an account? <Link to="/" style={{ color: "#1a237e" }}>Back to Home</Link>
        </p>
      </div>
    </div>
  );
};

export default RegisterPage;
