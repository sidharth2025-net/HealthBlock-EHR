import React, { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import { useWeb3 } from "../Web3Context";

const DoctorRegistration = () => {
  const { contracts, loading: web3Loading } = useWeb3();
  const navigate = useNavigate();

  const [form, setForm] = useState({
    name: "", specialization: "", hospitalName: "",
    email: "", hhNumber: "", password: "", confirmPassword: ""
  });
  const [status, setStatus] = useState({ type: "", msg: "" });
  const [loading, setLoading] = useState(false);

  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (form.password !== form.confirmPassword) {
      return setStatus({ type: "error", msg: "Passwords do not match!" });
    }
    setLoading(true);
    try {
      const exists = await contracts.doctorRegistration.isRegisteredDoctor(form.hhNumber);
      if (exists) {
        setStatus({ type: "error", msg: "Doctor with this HH Number already registered!" });
        setLoading(false);
        return;
      }
      const tx = await contracts.doctorRegistration.registerDoctor(
        form.name, form.specialization, form.hospitalName,
        form.email, form.hhNumber, form.password
      );
      await tx.wait();
      setStatus({ type: "success", msg: "✅ Doctor registered successfully! Redirecting..." });
      setTimeout(() => navigate("/doctor_login"), 2000);
    } catch (err) {
      setStatus({ type: "error", msg: "Registration failed: " + (err.reason || err.message) });
    } finally {
      setLoading(false);
    }
  };

  if (web3Loading) return <div className="loading"><div className="spinner"></div><p>Connecting...</p></div>;

  return (
    <div>
      <div className="page-header" style={{ background: "linear-gradient(135deg, #2e7d32, #388e3c)" }}>
        <h1>🩺 Doctor Registration</h1>
        <p>Register on the blockchain as a verified doctor</p>
      </div>
      <div className="container" style={{ maxWidth: "600px" }}>
        <div className="card">
          {status.msg && (
            <div className={`alert alert-${status.type === "success" ? "success" : "error"}`}>{status.msg}</div>
          )}
          <form onSubmit={handleSubmit}>
            <div className="form-group">
              <label>Full Name *</label>
              <input name="name" value={form.name} onChange={handleChange} required placeholder="Dr. Jane Smith" />
            </div>
            <div className="form-group">
              <label>Specialization *</label>
              <input name="specialization" value={form.specialization} onChange={handleChange} required placeholder="Cardiologist" />
            </div>
            <div className="form-group">
              <label>Hospital Name *</label>
              <input name="hospitalName" value={form.hospitalName} onChange={handleChange} required placeholder="City General Hospital" />
            </div>
            <div className="form-group">
              <label>Email *</label>
              <input name="email" type="email" value={form.email} onChange={handleChange} required />
            </div>
            <div className="form-group">
              <label>Doctor HH Number (Unique ID) *</label>
              <input name="hhNumber" value={form.hhNumber} onChange={handleChange} required placeholder="e.g. DOC001" />
            </div>
            <div className="grid-2">
              <div className="form-group">
                <label>Password *</label>
                <input name="password" type="password" value={form.password} onChange={handleChange} required />
              </div>
              <div className="form-group">
                <label>Confirm Password *</label>
                <input name="confirmPassword" type="password" value={form.confirmPassword} onChange={handleChange} required />
              </div>
            </div>
            <button type="submit" className="btn btn-success" disabled={loading} style={{ width: "100%", padding: "14px" }}>
              {loading ? "Registering..." : "Register Doctor"}
            </button>
          </form>
          <p style={{ textAlign: "center", marginTop: "15px", color: "#666" }}>
            Already registered? <Link to="/doctor_login" style={{ color: "#2e7d32" }}>Login here</Link>
          </p>
        </div>
      </div>
    </div>
  );
};

export default DoctorRegistration;
