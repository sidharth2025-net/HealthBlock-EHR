import React, { useState } from "react";
import { useWeb3 } from "../Web3Context";

const ConnectionStatus = () => {
  const { account, connectionMode, loading, error, contracts } = useWeb3();
  const [expanded, setExpanded] = useState(false);

  if (loading) {
    return (
      <div style={{
        background: "#fff8e1",
        padding: "8px 16px",
        textAlign: "center",
        fontSize: "0.85rem",
        color: "#e65100",
        borderBottom: "1px solid #ffe082"
      }}>
        ⏳ Connecting to blockchain...
      </div>
    );
  }

  if (error) {
    return (
      <div style={{
        background: "#ffebee",
        padding: "8px 16px",
        textAlign: "center",
        fontSize: "0.85rem",
        color: "#c62828",
        borderBottom: "1px solid #ef9a9a"
      }}>
        ❌ Blockchain connection error: {error}. Make sure Hardhat node is running on port 8545.
      </div>
    );
  }

  const isZeroAddress = !account || account === "0x0000000000000000000000000000000000000000";

  return (
    <div style={{
      background: connectionMode === "metamask" ? "#e8f5e9" : "#e3f2fd",
      padding: "6px 16px",
      display: "flex",
      justifyContent: "space-between",
      alignItems: "center",
      fontSize: "0.82rem",
      borderBottom: "1px solid #c8e6c9",
      flexWrap: "wrap",
      gap: "5px"
    }}>
      <span>
        {connectionMode === "metamask" ? "🦊 MetaMask" : "🔗 Local Hardhat Node"} | 
        Chain: 1337 (Localhost) | 
        Account: <code style={{ fontSize: "0.78rem" }}>
          {account ? `${account.slice(0, 8)}...${account.slice(-6)}` : "None"}
        </code>
      </span>
      <span style={{ color: "#2e7d32", fontWeight: 600 }}>
        ✅ Blockchain Connected
      </span>
    </div>
  );
};

export default ConnectionStatus;
