import React, { useState, useEffect } from "react";
import { useParams, useNavigate, Link } from "react-router-dom";
import { useWeb3 } from "../Web3Context";
import { getIPFSUrl } from "../ipfsUtils";

const ViewRecords = () => {
  const { hhNumber } = useParams();
  const { contracts, loading: web3Loading } = useWeb3();
  const navigate = useNavigate();
  const [records, setRecords] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!sessionStorage.getItem("loggedIn")) navigate("/patient_login");
  }, [navigate]);

  useEffect(() => {
    const load = async () => {
      if (web3Loading || !contracts.ehrContract) return;
      try {
        const recs = await contracts.ehrContract.getRecords(hhNumber);
        setRecords([...recs].reverse());
      } catch (e) { console.error(e); }
      finally { setLoading(false); }
    };
    load();
  }, [web3Loading, contracts, hhNumber]);

  if (loading || web3Loading) return <div className="loading"><div className="spinner"></div><p>Loading records...</p></div>;

  return (
    <div>
      <div className="page-header">
        <h1>📋 Your Health Records</h1>
        <p>{records.length} records found on blockchain</p>
      </div>
      <div className="container">
        <Link to={`/patient/${hhNumber}`} className="btn btn-secondary" style={{ marginBottom: "20px", display: "inline-block" }}>
          ← Back to Dashboard
        </Link>

        {records.length === 0 ? (
          <div className="alert alert-info">No health records found. Ask your doctor to create one.</div>
        ) : (
          records.map((r, i) => {
            const fileUrl = r.ipfsCid ? getIPFSUrl(r.ipfsCid) : null;
            return (
              <div key={i} className="record-card">
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", flexWrap: "wrap" }}>
                  <h3>Record #{r.recordId || (records.length - i)}</h3>
                  <span style={{ color: "#999", fontSize: "0.85rem" }}>
                    {new Date(Number(r.timestamp) * 1000).toLocaleDateString("en-IN", {
                      year: "numeric", month: "long", day: "numeric"
                    })}
                  </span>
                </div>
                <div className="meta">
                  👨‍⚕️ Dr. {r.doctorName || "Unknown"} | {r.doctorHhNumber && `HH: ${r.doctorHhNumber}`}
                </div>
                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "8px", margin: "12px 0" }}>
                  <div className="detail"><span>Patient:</span> {r.patientName}</div>
                  <div className="detail"><span>Age:</span> {r.age}</div>
                  <div className="detail"><span>Gender:</span> {r.gender}</div>
                  <div className="detail"><span>Blood Group:</span> {r.bloodGroup}</div>
                </div>
                <div style={{ background: "#f9f9f9", padding: "12px", borderRadius: "8px", marginBottom: "10px" }}>
                  <div className="detail" style={{ marginBottom: "8px" }}><span>🔬 Diagnosis:</span></div>
                  <p style={{ color: "#444", lineHeight: 1.5 }}>{r.diagnosis}</p>
                </div>
                <div style={{ background: "#f0f7ff", padding: "12px", borderRadius: "8px", marginBottom: "10px" }}>
                  <div className="detail" style={{ marginBottom: "8px" }}><span>💊 Prescription:</span></div>
                  <p style={{ color: "#444", lineHeight: 1.5 }}>{r.prescription}</p>
                </div>
                {r.ipfsCid && r.ipfsCid !== "" && (
                  <div style={{ background: "#f3e5f5", padding: "10px", borderRadius: "8px" }}>
                    <span style={{ fontSize: "0.85rem", color: "#6a1b9a" }}>
                      📁 IPFS File: <code>{r.ipfsCid.slice(0, 30)}...</code>
                    </span>
                    {fileUrl && (
                      <a href={fileUrl} target="_blank" rel="noopener noreferrer"
                        style={{ marginLeft: "10px", color: "#1a237e", fontSize: "0.85rem" }}>
                        View File →
                      </a>
                    )}
                  </div>
                )}
                <div style={{ marginTop: "10px" }}>
                  <span style={{ fontSize: "0.75rem", color: "#aaa" }}>
                    Created by: <code>{r.createdBy}</code>
                  </span>
                </div>
              </div>
            );
          })
        )}
      </div>
      <div className="footer"><p>Secure EHR System | Patient Records</p></div>
    </div>
  );
};

export default ViewRecords;
