/**
 * ipfsUtils.js
 * 
 * IPFS file upload/download utility for GitHub Codespaces.
 * 
 * Strategy:
 * 1. Try local IPFS node at http://localhost:5001 (if user runs ipfs daemon)
 * 2. Fallback: Use web3.storage API (requires token)
 * 3. Last resort: Store file as base64 in localStorage for demo purposes
 */

const IPFS_API = "http://localhost:5001/api/v0";
const W3S_TOKEN = process.env.REACT_APP_WEB3_STORAGE_TOKEN || "";

/**
 * Upload a file to IPFS.
 * Returns the CID string.
 */
export async function uploadToIPFS(file) {
  // Try local IPFS node first
  try {
    const formData = new FormData();
    formData.append("file", file);

    const response = await fetch(`${IPFS_API}/add?pin=true`, {
      method: "POST",
      body: formData,
    });

    if (response.ok) {
      const data = await response.json();
      console.log("Uploaded to local IPFS:", data.Hash);
      return { cid: data.Hash, source: "local-ipfs" };
    }
  } catch (e) {
    console.warn("Local IPFS not available:", e.message);
  }

  // Try web3.storage if token provided
  if (W3S_TOKEN) {
    try {
      const { Web3Storage } = await import("web3.storage");
      const client = new Web3Storage({ token: W3S_TOKEN });
      const cid = await client.put([file]);
      console.log("Uploaded to web3.storage:", cid);
      return { cid, source: "web3.storage" };
    } catch (e) {
      console.warn("web3.storage upload failed:", e.message);
    }
  }

  // Fallback: encode as base64 and store with a fake CID for demo
  return new Promise((resolve) => {
    const reader = new FileReader();
    reader.onload = () => {
      const base64 = reader.result;
      const fakeCid = "LOCAL_" + Date.now() + "_" + file.name.replace(/[^a-z0-9]/gi, "_");
      // Store in sessionStorage for retrieval
      sessionStorage.setItem("ipfs_" + fakeCid, base64);
      console.log("Stored file locally (demo mode). CID:", fakeCid);
      resolve({ cid: fakeCid, source: "demo-local" });
    };
    reader.readAsDataURL(file);
  });
}

/**
 * Get the URL to view an IPFS file.
 */
export function getIPFSUrl(cid) {
  if (!cid) return null;
  
  // Demo local file
  if (cid.startsWith("LOCAL_")) {
    return sessionStorage.getItem("ipfs_" + cid);
  }

  // Local IPFS gateway
  return `http://localhost:8080/ipfs/${cid}`;
}

/**
 * Download/view a file from IPFS.
 */
export async function getFromIPFS(cid) {
  if (!cid) return null;

  // Demo local file
  if (cid.startsWith("LOCAL_")) {
    return sessionStorage.getItem("ipfs_" + cid);
  }

  try {
    const response = await fetch(`http://localhost:8080/ipfs/${cid}`);
    if (response.ok) {
      const blob = await response.blob();
      return URL.createObjectURL(blob);
    }
  } catch (e) {
    console.warn("Could not fetch from local IPFS gateway");
  }

  // Try public gateway as fallback
  return `https://ipfs.io/ipfs/${cid}`;
}
