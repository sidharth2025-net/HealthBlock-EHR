/**
 * Web3Context.js
 * 
 * Handles blockchain connection for GitHub Codespaces.
 * - If MetaMask is available: uses it (prompts user to switch to localhost:8545)
 * - If no MetaMask: uses ethers.js JsonRpcProvider directly to localhost:8545
 * 
 * This makes the app work in GitHub Codespaces without requiring MetaMask.
 */

import React, { createContext, useState, useEffect, useContext } from "react";
import { ethers } from "ethers";
import deployedAddresses from "./deployedAddresses.json";

// ABIs
import PatientRegistrationABI from "./abis/PatientRegistration.json";
import DoctorRegistrationABI from "./abis/DoctorRegistration.json";
import DiagnosticRegistrationABI from "./abis/DiagnosticRegistration.json";
import EHRContractABI from "./abis/EHRContract.json";

const Web3Context = createContext(null);

export const useWeb3 = () => useContext(Web3Context);

export const Web3Provider = ({ children }) => {
  const [provider, setProvider] = useState(null);
  const [signer, setSigner] = useState(null);
  const [account, setAccount] = useState(null);
  const [contracts, setContracts] = useState({});
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [connectionMode, setConnectionMode] = useState(null); // 'metamask' | 'local'

  const RPC_URL = process.env.REACT_APP_RPC_URL || "http://localhost:8545";

  const initContracts = (signerOrProvider) => {
    return {
      patientRegistration: new ethers.Contract(
        deployedAddresses.PatientRegistration,
        PatientRegistrationABI,
        signerOrProvider
      ),
      doctorRegistration: new ethers.Contract(
        deployedAddresses.DoctorRegistration,
        DoctorRegistrationABI,
        signerOrProvider
      ),
      diagnosticRegistration: new ethers.Contract(
        deployedAddresses.DiagnosticRegistration,
        DiagnosticRegistrationABI,
        signerOrProvider
      ),
      ehrContract: new ethers.Contract(
        deployedAddresses.EHRContract,
        EHRContractABI,
        signerOrProvider
      ),
    };
  };

  useEffect(() => {
    const init = async () => {
      try {
        setLoading(true);

        if (window.ethereum) {
          // MetaMask available
          const web3Provider = new ethers.BrowserProvider(window.ethereum);
          
          // Try to switch to local hardhat network
          try {
            await window.ethereum.request({
              method: "wallet_switchEthereumChain",
              params: [{ chainId: "0x539" }], // 1337 in hex
            });
          } catch (switchError) {
            // Network not added yet, add it
            if (switchError.code === 4902) {
              try {
                await window.ethereum.request({
                  method: "wallet_addEthereumChain",
                  params: [{
                    chainId: "0x539",
                    chainName: "Hardhat Local",
                    rpcUrls: [RPC_URL],
                    nativeCurrency: { name: "ETH", symbol: "ETH", decimals: 18 },
                  }],
                });
              } catch (addError) {
                console.warn("Could not add Hardhat network to MetaMask:", addError);
              }
            }
          }

          await window.ethereum.request({ method: "eth_requestAccounts" });
          const web3Signer = await web3Provider.getSigner();
          const addr = await web3Signer.getAddress();

          setProvider(web3Provider);
          setSigner(web3Signer);
          setAccount(addr);
          setContracts(initContracts(web3Signer));
          setConnectionMode("metamask");

          window.ethereum.on("accountsChanged", async (accounts) => {
            if (accounts.length > 0) {
              const newSigner = await web3Provider.getSigner();
              setSigner(newSigner);
              setAccount(accounts[0]);
              setContracts(initContracts(newSigner));
            }
          });
        } else {
          // No MetaMask - use local JSON-RPC directly (Codespaces mode)
          const localProvider = new ethers.JsonRpcProvider(RPC_URL);
          
          // Use the first hardhat test account as default signer
          const accounts = await localProvider.listAccounts();
          if (accounts.length === 0) {
            throw new Error("No accounts found on local node. Make sure Hardhat is running.");
          }
          
          const localSigner = await localProvider.getSigner(0);
          const addr = await localSigner.getAddress();

          setProvider(localProvider);
          setSigner(localSigner);
          setAccount(addr);
          setContracts(initContracts(localSigner));
          setConnectionMode("local");
        }

        setError(null);
      } catch (err) {
        console.error("Web3 init error:", err);
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    init();
  }, []);

  return (
    <Web3Context.Provider value={{
      provider,
      signer,
      account,
      contracts,
      loading,
      error,
      connectionMode,
      deployedAddresses,
    }}>
      {children}
    </Web3Context.Provider>
  );
};

export default Web3Context;
