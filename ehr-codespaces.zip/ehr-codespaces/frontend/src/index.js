import React from "react";
import ReactDOM from "react-dom/client";
import "./App.css";
import App from "./App";
import { Web3Provider } from "./Web3Context";

const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(
  <Web3Provider>
    <App />
  </Web3Provider>
);
