import React from "react";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import { library } from "@fortawesome/fontawesome-svg-core";
import { faInstagram, faFacebookF, faLinkedinIn } from "@fortawesome/free-brands-svg-icons";

import LandingPage from "./components/LandingPage";
import RegisterPage from "./components/RegisterPage";
import PatientRegistration from "./components/PatientRegistration";
import DoctorRegistration from "./components/DoctorRegistration";
import DiagnosticRegistration from "./components/DiagnosticRegistration";
import PatientLogin from "./components/PatientLogin";
import DoctorLogin from "./components/DoctorLogin";
import DiagnosticLogin from "./components/DiagnosticLogin";
import PatientDashboard from "./components/PatientDashboard";
import DoctorDashboard from "./components/DoctorDashboard";
import DiagnosticDashboard from "./components/DiagnosticDashboard";
import CreateEHR from "./components/CreateEHR";
import ViewRecords from "./components/ViewRecords";
import ConnectionStatus from "./components/ConnectionStatus";
import "./App.css";

library.add(faInstagram, faFacebookF, faLinkedinIn);

function App() {
  return (
    <BrowserRouter>
      <ConnectionStatus />
      <Routes>
        <Route path="/" element={<LandingPage />} />
        <Route path="/register" element={<RegisterPage />} />
        <Route path="/patient_registration" element={<PatientRegistration />} />
        <Route path="/doctor_registration" element={<DoctorRegistration />} />
        <Route path="/diagnostic_registration" element={<DiagnosticRegistration />} />
        <Route path="/patient_login" element={<PatientLogin />} />
        <Route path="/doctor_login" element={<DoctorLogin />} />
        <Route path="/diagnostic_login" element={<DiagnosticLogin />} />
        <Route path="/patient/:hhNumber" element={<PatientDashboard />} />
        <Route path="/doctor/:hhNumber" element={<DoctorDashboard />} />
        <Route path="/diagnostic/:hhNumber" element={<DiagnosticDashboard />} />
        <Route path="/doctor/:hhNumber/create-ehr" element={<CreateEHR />} />
        <Route path="/patient/:hhNumber/viewrecords" element={<ViewRecords />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
