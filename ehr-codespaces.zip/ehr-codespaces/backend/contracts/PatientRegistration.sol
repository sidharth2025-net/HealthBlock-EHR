// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;

contract PatientRegistration {
    struct Patient {
        address walletAddress;
        string name;
        string dob;
        string gender;
        string bloodGroup;
        string homeAddress;
        string email;
        string hhNumber;
        string password;
        bool exists;
    }

    mapping(string => Patient) private patients; // hhNumber => Patient

    event PatientRegistered(string hhNumber, address walletAddress);

    function registerPatient(
        string memory _name,
        string memory _dob,
        string memory _gender,
        string memory _bloodGroup,
        string memory _homeAddress,
        string memory _email,
        string memory _hhNumber,
        string memory _password
    ) public {
        require(!patients[_hhNumber].exists, "Patient already registered");
        patients[_hhNumber] = Patient({
            walletAddress: msg.sender,
            name: _name,
            dob: _dob,
            gender: _gender,
            bloodGroup: _bloodGroup,
            homeAddress: _homeAddress,
            email: _email,
            hhNumber: _hhNumber,
            password: _password,
            exists: true
        });
        emit PatientRegistered(_hhNumber, msg.sender);
    }

    function isRegisteredPatient(string memory _hhNumber) public view returns (bool) {
        return patients[_hhNumber].exists;
    }

    function validatePassword(string memory _hhNumber, string memory _password) public view returns (bool) {
        require(patients[_hhNumber].exists, "Patient not found");
        return keccak256(bytes(patients[_hhNumber].password)) == keccak256(bytes(_password));
    }

    function getPatientDetails(string memory _hhNumber) public view returns (
        address walletAddress,
        string memory name,
        string memory dob,
        string memory gender,
        string memory bloodGroup,
        string memory homeAddress,
        string memory email
    ) {
        require(patients[_hhNumber].exists, "Patient not found");
        Patient memory p = patients[_hhNumber];
        return (p.walletAddress, p.name, p.dob, p.gender, p.bloodGroup, p.homeAddress, p.email);
    }
}
