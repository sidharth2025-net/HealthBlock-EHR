// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;

contract DoctorRegistration {
    struct Doctor {
        address walletAddress;
        string name;
        string specialization;
        string hospitalName;
        string email;
        string hhNumber;
        string password;
        bool exists;
    }

    mapping(string => Doctor) private doctors;

    event DoctorRegistered(string hhNumber, address walletAddress);

    function registerDoctor(
        string memory _name,
        string memory _specialization,
        string memory _hospitalName,
        string memory _email,
        string memory _hhNumber,
        string memory _password
    ) public {
        require(!doctors[_hhNumber].exists, "Doctor already registered");
        doctors[_hhNumber] = Doctor({
            walletAddress: msg.sender,
            name: _name,
            specialization: _specialization,
            hospitalName: _hospitalName,
            email: _email,
            hhNumber: _hhNumber,
            password: _password,
            exists: true
        });
        emit DoctorRegistered(_hhNumber, msg.sender);
    }

    function isRegisteredDoctor(string memory _hhNumber) public view returns (bool) {
        return doctors[_hhNumber].exists;
    }

    function validatePassword(string memory _hhNumber, string memory _password) public view returns (bool) {
        require(doctors[_hhNumber].exists, "Doctor not found");
        return keccak256(bytes(doctors[_hhNumber].password)) == keccak256(bytes(_password));
    }

    function getDoctorDetails(string memory _hhNumber) public view returns (
        address walletAddress,
        string memory name,
        string memory specialization,
        string memory hospitalName,
        string memory email
    ) {
        require(doctors[_hhNumber].exists, "Doctor not found");
        Doctor memory d = doctors[_hhNumber];
        return (d.walletAddress, d.name, d.specialization, d.hospitalName, d.email);
    }
}
