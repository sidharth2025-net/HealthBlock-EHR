// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;

contract EHRContract {
    struct Record {
        string recordId;
        string patientHhNumber;
        string doctorHhNumber;
        string patientName;
        string doctorName;
        string age;
        string gender;
        string bloodGroup;
        string diagnosis;
        string prescription;
        string ipfsCid; // IPFS CID for attached files
        uint256 timestamp;
        address createdBy;
    }

    // patientHhNumber => list of records
    mapping(string => Record[]) private patientRecords;

    // Track allowed doctors per patient: patientHH => doctorHH => allowed
    mapping(string => mapping(string => bool)) private accessPermissions;

    event RecordCreated(string recordId, string patientHhNumber, address createdBy);
    event AccessGranted(string patientHhNumber, string doctorHhNumber);
    event AccessRevoked(string patientHhNumber, string doctorHhNumber);

    function createRecord(
        string memory _recordId,
        string memory _patientHhNumber,
        string memory _doctorHhNumber,
        string memory _patientName,
        string memory _doctorName,
        string memory _age,
        string memory _gender,
        string memory _bloodGroup,
        string memory _diagnosis,
        string memory _prescription,
        string memory _ipfsCid
    ) public {
        Record memory r = Record({
            recordId: _recordId,
            patientHhNumber: _patientHhNumber,
            doctorHhNumber: _doctorHhNumber,
            patientName: _patientName,
            doctorName: _doctorName,
            age: _age,
            gender: _gender,
            bloodGroup: _bloodGroup,
            diagnosis: _diagnosis,
            prescription: _prescription,
            ipfsCid: _ipfsCid,
            timestamp: block.timestamp,
            createdBy: msg.sender
        });
        patientRecords[_patientHhNumber].push(r);
        emit RecordCreated(_recordId, _patientHhNumber, msg.sender);
    }

    function getRecords(string memory _patientHhNumber) public view returns (Record[] memory) {
        return patientRecords[_patientHhNumber];
    }

    function grantAccess(string memory _patientHhNumber, string memory _doctorHhNumber) public {
        accessPermissions[_patientHhNumber][_doctorHhNumber] = true;
        emit AccessGranted(_patientHhNumber, _doctorHhNumber);
    }

    function revokeAccess(string memory _patientHhNumber, string memory _doctorHhNumber) public {
        accessPermissions[_patientHhNumber][_doctorHhNumber] = false;
        emit AccessRevoked(_patientHhNumber, _doctorHhNumber);
    }

    function hasAccess(string memory _patientHhNumber, string memory _doctorHhNumber) public view returns (bool) {
        return accessPermissions[_patientHhNumber][_doctorHhNumber];
    }
}
