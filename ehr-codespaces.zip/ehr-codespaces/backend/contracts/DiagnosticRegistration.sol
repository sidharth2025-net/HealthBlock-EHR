// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;

contract DiagnosticRegistration {
    struct Diagnostic {
        address walletAddress;
        string diagnosticName;
        string hospitalName;
        string diagnosticLocation;
        string email;
        string hhNumber;
        string password;
        bool exists;
    }

    mapping(string => Diagnostic) private diagnostics;

    event DiagnosticRegistered(string hhNumber, address walletAddress);

    function registerDiagnostic(
        string memory _diagnosticName,
        string memory _hospitalName,
        string memory _diagnosticLocation,
        string memory _email,
        string memory _hhNumber,
        string memory _password
    ) public {
        require(!diagnostics[_hhNumber].exists, "Diagnostic already registered");
        diagnostics[_hhNumber] = Diagnostic({
            walletAddress: msg.sender,
            diagnosticName: _diagnosticName,
            hospitalName: _hospitalName,
            diagnosticLocation: _diagnosticLocation,
            email: _email,
            hhNumber: _hhNumber,
            password: _password,
            exists: true
        });
        emit DiagnosticRegistered(_hhNumber, msg.sender);
    }

    function isRegisteredDiagnostic(string memory _hhNumber) public view returns (bool) {
        return diagnostics[_hhNumber].exists;
    }

    function validatePassword(string memory _hhNumber, string memory _password) public view returns (bool) {
        require(diagnostics[_hhNumber].exists, "Diagnostic not found");
        return keccak256(bytes(diagnostics[_hhNumber].password)) == keccak256(bytes(_password));
    }

    function getDiagnosticDetails(string memory _hhNumber) public view returns (
        address walletAddress,
        string memory _diagnosticName,
        string memory _hospitalName,
        string memory _diagnosticLocation,
        string memory _email
    ) {
        require(diagnostics[_hhNumber].exists, "Diagnostic not found");
        Diagnostic memory d = diagnostics[_hhNumber];
        return (d.walletAddress, d.diagnosticName, d.hospitalName, d.diagnosticLocation, d.email);
    }
}
