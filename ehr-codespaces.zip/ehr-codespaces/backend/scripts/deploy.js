const fs = require("fs");
const path = require("path");

async function main() {
  const [deployer] = await ethers.getSigners();
  console.log("Deploying contracts with:", deployer.address);
  console.log("Account balance:", (await ethers.provider.getBalance(deployer.address)).toString());

  // Deploy PatientRegistration
  const PatientRegistration = await ethers.getContractFactory("PatientRegistration");
  const patientReg = await PatientRegistration.deploy();
  await patientReg.waitForDeployment();
  const patientRegAddr = await patientReg.getAddress();
  console.log("PatientRegistration deployed to:", patientRegAddr);

  // Deploy DoctorRegistration
  const DoctorRegistration = await ethers.getContractFactory("DoctorRegistration");
  const doctorReg = await DoctorRegistration.deploy();
  await doctorReg.waitForDeployment();
  const doctorRegAddr = await doctorReg.getAddress();
  console.log("DoctorRegistration deployed to:", doctorRegAddr);

  // Deploy DiagnosticRegistration
  const DiagnosticRegistration = await ethers.getContractFactory("DiagnosticRegistration");
  const diagnosticReg = await DiagnosticRegistration.deploy();
  await diagnosticReg.waitForDeployment();
  const diagnosticRegAddr = await diagnosticReg.getAddress();
  console.log("DiagnosticRegistration deployed to:", diagnosticRegAddr);

  // Deploy EHRContract
  const EHRContract = await ethers.getContractFactory("EHRContract");
  const ehrContract = await EHRContract.deploy();
  await ehrContract.waitForDeployment();
  const ehrContractAddr = await ehrContract.getAddress();
  console.log("EHRContract deployed to:", ehrContractAddr);

  // Save addresses
  const addresses = {
    PatientRegistration: patientRegAddr,
    DoctorRegistration: doctorRegAddr,
    DiagnosticRegistration: diagnosticRegAddr,
    EHRContract: ehrContractAddr,
    network: "localhost",
    chainId: 1337,
    deployedAt: new Date().toISOString(),
  };

  const outputPath = path.join(__dirname, "../deployedAddresses.json");
  fs.writeFileSync(outputPath, JSON.stringify(addresses, null, 2));
  console.log("\nDeployed addresses saved to:", outputPath);

  // Also copy to frontend
  const frontendPath = path.join(__dirname, "../../frontend/src/deployedAddresses.json");
  if (fs.existsSync(path.dirname(frontendPath))) {
    fs.writeFileSync(frontendPath, JSON.stringify(addresses, null, 2));
    console.log("Addresses also copied to frontend/src/deployedAddresses.json");
  }

  console.log("\n=== DEPLOYMENT COMPLETE ===");
  console.log(JSON.stringify(addresses, null, 2));
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
