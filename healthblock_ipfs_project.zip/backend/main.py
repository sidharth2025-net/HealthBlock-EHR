import os
from fastapi import FastAPI, UploadFile, File, Form, Depends, HTTPException
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
from passlib.context import CryptContext
from pydantic import BaseModel
import databases, sqlalchemy
import httpx
from jose import jwt, JWTError
from typing import List

DATABASE_URL = "sqlite:///./healthblock.db"
database = databases.Database(DATABASE_URL)
metadata = sqlalchemy.MetaData()
engine = sqlalchemy.create_engine(DATABASE_URL, connect_args={"check_same_thread": False})

users = sqlalchemy.Table(
    "users", metadata,
    sqlalchemy.Column("id", sqlalchemy.Integer, primary_key=True),
    sqlalchemy.Column("username", sqlalchemy.String, unique=True),
    sqlalchemy.Column("password", sqlalchemy.String),
    sqlalchemy.Column("role", sqlalchemy.String),  # patient, doctor, lab
)

records = sqlalchemy.Table(
    "records", metadata,
    sqlalchemy.Column("id", sqlalchemy.Integer, primary_key=True),
    sqlalchemy.Column("owner_id", sqlalchemy.Integer),
    sqlalchemy.Column("cid", sqlalchemy.String),
    sqlalchemy.Column("filename", sqlalchemy.String),
    sqlalchemy.Column("type", sqlalchemy.String),  # lab, prescription, other
    sqlalchemy.Column("uploader_id", sqlalchemy.Integer),
)

acl = sqlalchemy.Table(
    "acl", metadata,
    sqlalchemy.Column("id", sqlalchemy.Integer, primary_key=True),
    sqlalchemy.Column("patient_id", sqlalchemy.Integer),
    sqlalchemy.Column("user_id", sqlalchemy.Integer),
)

metadata.create_all(engine)

app = FastAPI(title="HealthBlock IPFS Demo")

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/token")
SECRET = os.getenv("SECRET_KEY", "changeme123")

class UserCreate(BaseModel):
    username: str
    password: str
    role: str

async def get_user_by_username(username: str):
    query = users.select().where(users.c.username==username)
    return await database.fetch_one(query)

async def authenticate_user(username: str, password: str):
    user = await get_user_by_username(username)
    if not user: return None
    if not pwd_context.verify(password, user['password']): return None
    return user

async def get_current_user(token: str = Depends(oauth2_scheme)):
    try:
        payload = jwt.decode(token, SECRET, algorithms=["HS256"])
        username = payload.get("sub")
        if username is None:
            raise HTTPException(status_code=401, detail="Invalid token")
    except JWTError:
        raise HTTPException(status_code=401, detail="Invalid token")
    user = await get_user_by_username(username)
    if not user:
        raise HTTPException(status_code=401, detail="User not found")
    return user

@app.on_event("startup")
async def startup():
    await database.connect()

@app.on_event("shutdown")
async def shutdown():
    await database.disconnect()

@app.post("/register")
async def register(u: UserCreate):
    user = await get_user_by_username(u.username)
    if user:
        raise HTTPException(status_code=400, detail="username exists")
    hashed = pwd_context.hash(u.password)
    query = users.insert().values(username=u.username, password=hashed, role=u.role)
    uid = await database.execute(query)
    return {"id": uid, "username": u.username, "role": u.role}

@app.post("/token")
async def token(form_data: OAuth2PasswordRequestForm = Depends()):
    user = await authenticate_user(form_data.username, form_data.password)
    if not user:
        raise HTTPException(status_code=400, detail="Incorrect credentials")
    token = jwt.encode({"sub": user['username']}, SECRET, algorithm="HS256")
    return {"access_token": token, "token_type": "bearer"}

@app.post("/grant_access")
async def grant_access(patient_id: int = Form(...), user_id: int = Form(...), me=Depends(get_current_user)):
    # only patient owner can grant
    if me['role']!='patient' or me['id']!=patient_id:
        raise HTTPException(status_code=403, detail="only patient can grant access to their records")
    q = acl.insert().values(patient_id=patient_id, user_id=user_id)
    await database.execute(q)
    return {"ok": True}

@app.post("/upload_record")
async def upload_record(owner_id: int = Form(...), type: str = Form(...), file: UploadFile = File(...), me=Depends(get_current_user)):
    # role checks: patient uploads their own; lab can upload if granted; doctor can upload prescriptions
    # check permission
    if me['role']=='patient' and me['id']!=owner_id:
        raise HTTPException(status_code=403, detail="patients can only upload for themselves")
    if me['role']=='lab' and me['id']==owner_id:
        pass
    # if lab, ensure patient granted access
    if me['role']=='lab':
        acl_q = acl.select().where((acl.c.patient_id==owner_id) & (acl.c.user_id==me['id']))
        allowed = await database.fetch_one(acl_q)
        if not allowed:
            raise HTTPException(status_code=403, detail="lab not granted access by patient")
    # save file to temp and add to local ipfs node
    contents = await file.read()
    async with httpx.AsyncClient() as client:
        files = {"file": (file.filename, contents)}
        # assume ipfs API at http://ipfs:5001/api/v0/add
        try:
            r = await client.post("http://ipfs:5001/api/v0/add", files=files, timeout=30.0)
            r.raise_for_status()
            resp = r.text
            # response is like: {"Name":"...","Hash":"Qm...","Size":"..."} per line; decode simply
            import json
            j = json.loads(r.text)
            cid = j.get("Hash") or j.get("CID") or (j[0].get('Hash') if isinstance(j, list) else None)
        except Exception as e:
            raise HTTPException(status_code=500, detail=f"IPFS add failed: {e}")
    q = records.insert().values(owner_id=owner_id, cid=cid, filename=file.filename, type=type, uploader_id=me['id'])
    rid = await database.execute(q)
    return {"id": rid, "cid": cid, "filename": file.filename}

@app.get("/records/{patient_id}")
async def list_records(patient_id: int, me=Depends(get_current_user)):
    # doctor can view; patient can view their own; lab only if granted
    if me['role']=='doctor':
        pass
    elif me['role']=='patient' and me['id']==patient_id:
        pass
    elif me['role']=='lab':
        acl_q = acl.select().where((acl.c.patient_id==patient_id) & (acl.c.user_id==me['id']))
        allowed = await database.fetch_one(acl_q)
        if not allowed:
            raise HTTPException(status_code=403, detail="not allowed")
    else:
        raise HTTPException(status_code=403, detail="not allowed")
    q = records.select().where(records.c.owner_id==patient_id)
    rows = await database.fetch_all(q)
    return [dict(r) for r in rows]

@app.get("/record/{cid}")
async def proxy_record(cid: str, me=Depends(get_current_user)):
    # fetch via public gateway and stream back URL to user
    return {"url": f"https://ipfs.io/ipfs/{cid}"}
