# HealthBlock IPFS Demo

Minimal demo: patient/doctor/lab roles, records stored on local IPFS node and metadata in SQLite.

Services:
- ipfs: go-ipfs node (API on port 5001)
- backend: FastAPI (port 8000)
- frontend: static HTML served by nginx (port 3000)

Quick start with Docker (requires Docker & Docker Compose):
1. git clone <this repo>
2. docker-compose up --build
3. Open frontend: http://localhost:3000
4. Backend API: http://localhost:8000

GitHub Codespaces:
- Open the repository in Codespaces.
- In a terminal run: `docker-compose up --build`
- If Codespaces doesn't allow Docker-in-Docker, run backend locally:
  - cd backend
  - python -m venv .venv
  - source .venv/bin/activate
  - pip install -r requirements.txt
  - uvicorn main:app --reload --host 0.0.0.0 --port 8000
  - Start a local IPFS daemon in Codespaces terminal: `ipfs init && ipfs daemon` (if allowed)

Notes & limitations:
- This is a demo scaffold. It uses SQLite for simplicity.
- Access control is simplified: patient grants access by storing ACL entries.
- IPFS add uses the IPFS HTTP API at http://ipfs:5001/api/v0/add inside Docker.
- In production you must secure secrets, use TLS, proper auth, and persistent DB.
