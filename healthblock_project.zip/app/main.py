from flask import Blueprint, render_template, request, redirect, url_for, flash, jsonify
from flask_login import login_required, current_user
from .models import Hospital, Doctor, Appointment, PatientRecord, User
from . import db
import hashlib, json

main_bp = Blueprint('main', __name__)

@main_bp.route('/')
def index():
    return render_template('index.html')

@main_bp.route('/hospitals')
@login_required
def hospitals():
    hs = Hospital.query.all()
    return render_template('hospitals.html', hospitals=hs)

@main_bp.route('/doctors')
@login_required
def doctors():
    docs = Doctor.query.all()
    return render_template('doctors.html', doctors=docs)

@main_bp.route('/appointments', methods=['GET','POST'])
@login_required
def appointments():
    if request.method == 'POST':
        doctor_id = request.form.get('doctor_id')
        date = request.form.get('date')
        notes = request.form.get('notes')
        appt = Appointment(patient_id=current_user.id, doctor_id=doctor_id, date=date, notes=notes)
        db.session.add(appt)
        db.session.commit()
        flash('Appointment created', 'success')
        return redirect(url_for('main.appointments'))
    appts = Appointment.query.filter_by(patient_id=current_user.id).all()
    doctors = Doctor.query.all()
    return render_template('appointments.html', appointments=appts, doctors=doctors)

@main_bp.route('/wallet', methods=['GET','POST'])
@login_required
def wallet():
    if request.method == 'POST':
        amount = float(request.form.get('amount', 0))
        current_user.wallet_balance += amount
        db.session.commit()
        flash(f'Added {amount} to wallet', 'success')
        return redirect(url_for('main.wallet'))
    return render_template('wallet.html')

# Patient records - creation visible to patient and hospital admin
@main_bp.route('/records', methods=['GET','POST'])
@login_required
def records():
    # if hospital admin, show records for their hospital(s). For simplicity the admin can view all.
    if request.method == 'POST':
        patient_id = int(request.form.get('patient_id'))
        hospital_id = int(request.form.get('hospital_id'))
        data = request.form.get('data')
        # create deterministic SHA256 hash of data+patient_id+hospital_id+timestamp for transparency
        payload = {'patient_id': patient_id, 'hospital_id': hospital_id, 'data': data}
        payload_str = json.dumps(payload, sort_keys=True)
        record_hash = hashlib.sha256(payload_str.encode('utf-8')).hexdigest()
        rec = PatientRecord(patient_id=patient_id, hospital_id=hospital_id, data=data, record_hash=record_hash)
        db.session.add(rec)
        db.session.commit()
        # return the generated hash so frontend can show popup
        flash('Record created. Hash generated.', 'success')
        return jsonify({'status':'ok','hash':record_hash})
    # GET - list records for patient or hospital admin
    if current_user.role == 'hospital_admin':
        recs = PatientRecord.query.all()
    else:
        recs = PatientRecord.query.filter_by(patient_id=current_user.id).all()
    patients = User.query.filter_by(role='patient').all()
    hospitals = Hospital.query.all()
    return render_template('records.html', records=recs, patients=patients, hospitals=hospitals)
