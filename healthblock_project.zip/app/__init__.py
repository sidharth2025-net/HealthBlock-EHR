from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager

db = SQLAlchemy()
login_manager = LoginManager()

def create_app():
    app = Flask(__name__)
    app.config['SECRET_KEY'] = 'change_this_secret_in_production'
    app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///healthblock.db'
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

    db.init_app(app)
    login_manager.init_app(app)
    login_manager.login_view = 'auth.login'

    with app.app_context():
        from . import models
        db.create_all()

        # register blueprints
        from .auth import auth_bp
        from .main import main_bp
        app.register_blueprint(auth_bp)
        app.register_blueprint(main_bp)

    return app
