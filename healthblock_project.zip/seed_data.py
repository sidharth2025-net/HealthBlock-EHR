from app import create_app, db
from app.models import Hospital, Doctor, User
import bcrypt

app = create_app()
with app.app_context():
    if not User.query.filter_by(email='admin@hospital.com').first():
        pw = bcrypt.hashpw('adminpass'.encode('utf-8'), bcrypt.gensalt())
        u = User(email='admin@hospital.com', name='Admin', password=pw, role='hospital_admin')
        db.session.add(u)
    if not User.query.filter_by(email='patient@example.com').first():
        pw = bcrypt.hashpw('patientpass'.encode('utf-8'), bcrypt.gensalt())
        p = User(email='patient@example.com', name='John Patient', password=pw, role='patient', wallet_balance=100.0)
        db.session.add(p)
    if not Hospital.query.filter_by(name='City Hospital').first():
        h = Hospital(name='City Hospital', address='123 Main St')
        db.session.add(h)
        db.session.flush()
        d = Doctor(name='Dr. Alice', specialization='Cardiology', hospital_id=h.id)
        db.session.add(d)
    db.session.commit()
    print('Seeded data.')
