# Health Block - EHR (Demo)
A small demo Electronic Health Record web app with blockchain-like hashed patient records for transparency. Built with Flask and SQLite, containerized with Docker.

## Features
- Register / Login (roles: patient, hospital_admin)
- Hospitals, Doctors listing
- Create Appointments
- Wallet (add funds)
- Create Patient Records: each record's hash (SHA-256) is generated and returned; shown in a popup for auditability.
- Records visible to patient and hospital admin. No third-party services.

## Quick start (requires Docker & Docker Compose)
1. Unzip the project and `cd` into the project folder.
2. Build & run with Docker Compose:
   ```bash
   docker compose up --build
   ```
3. On first run you may want to create seed data:
   ```bash
   docker compose exec web python seed_data.py
   ```
4. Open http://localhost:5000 in your browser.
   - Seeded users: admin@hospital.com / adminpass (hospital_admin)
   - patient@example.com / patientpass (patient)

## Without Docker (local)
1. Create a virtualenv, install requirements: `pip install -r requirements.txt`
2. Run `python seed_data.py` to create sample data.
3. Run `python run.py` and open http://127.0.0.1:5000

## Notes & Next steps
- The record hash is a deterministic SHA-256 of the JSON payload (patient_id, hospital_id, data). For a production blockchain solution you'd append the hash into an append-only ledger or real blockchain.
- SECRET_KEY in app/__init__.py should be changed in production.
- This demo uses SQLite for simplicity. For production use a managed DB and secure secrets.
